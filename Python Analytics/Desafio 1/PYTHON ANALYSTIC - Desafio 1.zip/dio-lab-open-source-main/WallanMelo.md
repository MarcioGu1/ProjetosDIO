<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=D41b22&height=180&section=header&text=Wallan+Melo&fontSize=27&fontColor=00CED1&animation=twinkling&fontAlignY=35"/>

# Wallan Melo
Cursando Bacharelado em Sistemas de Informação no [IFNMG-Januária](https://www.ifnmg.edu.br/januaria)

## Conecte-se comigo
[![My profile DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DER?style=for-the-badge)](https://www.dio.me/users/walandemelo1)
[![Beacons](https://img.shields.io/badge/-Minhas%20Redes%20Sociais%20-30A3DE?style=for-the-badge)](https://beacons.ai/wallan7melo)

## Habilidades 
![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white)
![C](https://img.shields.io/badge/C-00599C?style=for-the-badge&logo=c&logoColor=white)
![C#](https://img.shields.io/badge/C%23-239120?style=for-the-badge&logo=c-sharp&logoColor=white)
![MySQL](https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white)
