# Olá, sou o Everton, tudo bem?

Sou Analista de Segurança da informação formado em TECNOLOGIA EM SEGURANÇA DA INFORMAÇÃO .
Atualmente trabalho como assistente de suporte técnico no Seconci-sp, onde minha função é Prestar suporte na identificação de dificuldades e solução de incidentes e problemas de hardware, redes e software, envolvendo a montagem, reparo e configuração de equipamentos, Criação e configuração de e-mail no Microsoft Exchange 2013, e criação e gestão de usuários e computadores no Active Directory.
## Minhas habilidades

#Active Directory
#Microsoft Exchange
#kaspersky security center
#ocs inventory
#GLPI
#File Server
#ArcServer

## Contate-me

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/everton-seguran%C3%A7a-da-informacao/?midSig=0u_dpJjc0z5X81&eid=fc564o-ls57tupk-pe&midToken=AQF2kEQuRQo7aQ&trkEmail=eml-email_edge_discover_01-header-0-profile_glimmer-null-fc564o%7Els57tupk%7Epe-null-null&trk=eml-email_edge_discover_01-header-0-profile_glimmer&originalSubdomain=br)https://www.linkedin.com/in/everton-seguran%C3%A7a-da-informacao/?midSig=0u_dpJjc0z5X81&eid=fc564o-ls57tupk-pe&midToken=AQF2kEQuRQo7aQ&trkEmail=eml-email_edge_discover_01-header-0-profile_glimmer-null-fc564o%7Els57tupk%7Epe-null-null&trk=eml-email_edge_discover_01-header-0-profile_glimmer&originalSubdomain=br)

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/EvertonALucas)https://github.com/EvertonALucas)



