# Olaarr a todos!!

        Meu nome é André, tenho 32 (1991), sou formado em Administração, no entanto estou realizando transição de carreira.

        Completei 60% do curso "Formação Python Developer", da Digital Innovation, mas dei uma pausa e estou priorizando o "BootCamp Santader 2023 - Ciência de Dados com Python".

# Habilidades
        Iniciante: HTML, CSS.
        Intermediário: VBA, SQL, Power BI, Python.
        Avançado: Excel.

# Objetivo
        Ingressar na carrreira de programação, enfatizando a área de Ciência de Dados com a Linguagem Python.

### Contato:
    [Linkedin](https://www.linkedin.com/in/iwanaga-andre/)|