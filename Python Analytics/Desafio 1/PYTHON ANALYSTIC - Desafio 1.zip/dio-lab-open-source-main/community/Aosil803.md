# Aosil803 minha conta do GitHub

## Alexandre de  oliveira Silveira
Estudante de Análise e Desenvolvimento de Sistesmas, com entusiasmo iniciando um novo desafio profissional.
## Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/aosil803)
[![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red)](mailto:Aosil803@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](www.linkedin.com/in/alexandre-silveira-686699178)

              
## Habilidades
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)

## Git stats

## Minhas Contribuições
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Aosil803&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Aosil803&repo=projeto_MVP&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Aosil803/projeto_MVP)

Gostei muito de participar do projeto da Dio Lab_Open_Source, serviu pra colocar em praticas ensinamentos no Git e GitHub.