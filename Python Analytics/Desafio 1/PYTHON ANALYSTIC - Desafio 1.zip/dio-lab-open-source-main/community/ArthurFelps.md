# Arthur Felipe

Futuro Dev cursando Engenharia de Computação na UNIUBE.

## Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-057?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/arthur-felipe-alves-565565244/)

[![GitHub](https://img.shields.io/badge/GitHub-057?style=for-the-badge&logo=github&logoColor=white)](https://web.dio.me/users/arthurfelipealves2013?)

[![DIO](https://img.shields.io/badge/MEU_PERFIL_NA_DIO-057?style=for-the-badge&logoColor=white)](https://web.dio.me/users/arthurfelipealves2013)

## Habilidades

![HTML5](https://img.shields.io/badge/HTML5-057?style=for-the-badge&logo=html5&logoColor=white)

![CSS3](https://img.shields.io/badge/CSS3-057?style=for-the-badge&logo=css3&logoColor=white)

![JavaScript](https://img.shields.io/badge/JavaScript-057?style=for-the-badge&logo=javascript&logoColor=White)

![C](https://img.shields.io/badge/C-057?style=for-the-badge&logo=c&logoColor=white)

![React Native](https://img.shields.io/badge/React_Native-057?style=for-the-badge&logo=react&logoColor=white)

![MySQL](https://img.shields.io/badge/MySQL-057?style=for-the-badge&logo=mysql&logoColor=white)

![PostgreSQL](https://img.shields.io/badge/PostgreSQL-057?style=for-the-badge&logo=postgresql&logoColor=white)

**Ferramentas

## Github Status
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=ArthurFelps&theme=transparent&bg_color=057&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=ArthurFelps&layout=compact&bg_color=057&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Minhas Contribuições

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=ArthurFelps&repo=dio-lab-open-source&bg_color=057&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/ArthurFelps/dio-lab-open-source)