## Oi, sou Antonio Aldacélio prazer em tê-lo no meu perfil👋
<!-- ### Hi, I'm Antonio Aldacélio, nice to have you on my profile👋 -->

- 👤 24 anos de idade
<!-- - 👤 24 years old -->
- 🎓 Sistemas de Informação - Universidade Federal do Ceará
<!-- - 🎓 Information Systems - Federal University of Ceará -->
- 💼 Atualmente estou em busca de oportunidades para ingressar no mercado
de trabalho.
<!--- 💼 I am currently looking for opportunities to enter the market
of work.-->
- 💻 Atualmente estou buscando aprender mais sobre linguagens que já conheço<br>
para aperfeiçoar mais ainda meus conhecimentos.
<!--- 💻 I'm currently looking to learn more about languages I already know<br>
to further improve my knowledge.-->
- 👯 Estou em busca de colaborar com novos projetos, sejam eles Desktop, Web ou Mobile.
<!--- 👯 I'm looking to collaborate with new projects, whether Desktop, Web or Mobile.-->
- Portfólio: https://aldacelio.github.io/Portfolio/
##

<div>
  <a href="https://github.com/Aldacelio">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=aldacelio&show_icons=true&theme=github_dark&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=aldacelio&layout=compact&langs_count=7&theme=github_dark"/>
</div>

<div style="display: inline_block"><br>
  <img align="center" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <!--<img align="center" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/typescript/typescript-plain.svg">-->
  <img align="center" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg">
  <img align="center" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg">
  <img align="center" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/nodejs/nodejs-original.svg">
  <img align="center" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/c/c-original.svg">
  <img align="center" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mongodb/mongodb-original.svg">
  <img align="center" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/postgresql/postgresql-original.svg">
  <img align="center" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original.svg">
  
<img align="right" height="150" style="border-radius:50px;" src="https://media.discordapp.net/attachments/935327373509939234/1028114434331250728/avatar_1665191663147.png?width=676&height=676">
</div>
  
  ##
  
<div>
<a href="" target="_blank"><img src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" target="_blank"></a>
<a href="https://www.instagram.com/aldacelio.dev/" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
<a href="https://www.facebook.com/profile.php?id=100086592729470" target="_blank"><img src="https://img.shields.io/badge/Facebook-1877F2?style=for-the-badge&logo=facebook&logoColor=white" target="_blank"></a>
<a href="https://twitter.com/AldacelioDe" target="_blank"><img src="https://img.shields.io/badge/Twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white" target="_blank"></a>
<a href = "mailto:contatoaldacelio368@gmail.com"><img src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/antonio-aldacélio-cavalcante-a42a1212b/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
</div>

  ##
  ![snake gif](https://github.com/Aldacelio/Aldacelio/blob/output/github-contribution-grid-snake.svg)
