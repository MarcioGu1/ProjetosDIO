# Alan Eliotério

Olá, sou Alan Eliotério,
Sou desenvolvedor, e atualmente sou estagiário de informática na Embraer. Estou fazendo esse bootcamp na DIO para melhorar minhas habilidades no Angular.JS e consequentemente em outras ferramentas, como o Git e Github.

## Linguagens mais utiizadas 

 - Python
 - C#
 - Node.js
 - PHP

## Contatos pessoais
[![LinkedIn](https://img.shields.io/badge/LinkedIn-f8f8f2?style=for-the-badge&logo=linkedin&logoColor=green)](https://www.linkedin.com/in/alanelioterio/)[![Instagram](https://img.shields.io/badge/Instagram-f8f8f2?style=for-the-badge&logo=instagram&logoColor=green)](https://www.linkedin.com/in/alanelioterio/)


## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlanElioterio&show_icons=true&hide=contribs,prs&cache_seconds=86400&theme=dark)
