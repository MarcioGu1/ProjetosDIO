## William Arantes

Bem-vindos ao meu GitHub! Aqui, você acompanhará minha jornada de aprendizado. Atualmente, estou no 1º semestre do curso de Análise e Desenvolvimento de Sistemas. Além disso, participo do programa Santander Bootcamp 2023 - Ciência de Dados com Python / DIO e também do programa 1000Devs, desenvolvido pela Johnson & Johnson MedTech em parceria com a Mesttra.


### O que estou aprendendo?
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git)
![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=Github)

### Onde me encontrar
[![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=github)](https://github.com/Arantes-Will)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/william-arantes-7ab35a27b/)


![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Arantes-Will&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=#A9A9A9text_color=FFF)