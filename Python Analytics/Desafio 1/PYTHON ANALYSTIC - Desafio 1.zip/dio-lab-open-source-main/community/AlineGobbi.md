# Olá , eu sou a Aline  :)

Meu nome é Aline Gobbi, tenho formação inicial na área da saúde, no mestrado me apaixonei pro estatística, fiz MBA em DSA, e estou em momento de transição de carreira. 

Meu Linkedin 
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/aline-gobbi-53702313a/)
