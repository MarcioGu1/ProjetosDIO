# Olá, eu me chamo Alyasaf Meireles.

Me chamo Alyasaf, estou no mundo da programação a 2 anos, espero que goste dos meus códigos.

<a href="https://www.linkedin.com/in/alyasaf/">
 <img src="https://skillicons.dev/icons?i=linkedin">
</a>


## Tecnologias que tenho conhecimento:
<p align="center">
  <a href="https://skillicons.dev">
    <img src="https://skillicons.dev/icons?i=git,java,spring,js,nodejs,nestjs,express,react,ts,angular,tailwind,php,prisma,mysql,postgres,docker,&perline=6" />
  </a>
</p>


## Tecnologias e ferramentas que tenho interesse em aprender:
<p align="center">
  <a href="https://skillicons.dev">
    <img src="https://skillicons.dev/icons?i=laravel,mongodb,go,linux" />
  </a>
</p>

<p><img align="left" src="https://github-readme-stats.vercel.app/api/top-langs?username=alym62&show_icons=true&locale=en&layout=compact" alt="alym62" /></p>

<p>&nbsp;<img align="center" src="https://github-readme-stats.vercel.app/api?username=alym62&show_icons=true&locale=en" alt="alym62" /></p>



