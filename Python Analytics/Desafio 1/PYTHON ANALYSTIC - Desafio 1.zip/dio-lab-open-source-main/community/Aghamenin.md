# Aghamenin Louren�o da Silva

Estudante p�s graduando em administra��o de banco de dados.
Graduado em An�lise e desenvolvimento de sistema.

# 

# Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/aghamenin-silva-ab2009224/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/hornin2022/)

# Estudos de Linguagens 

|Curso | 
|------|
|![SQL](https://img.shields.io/badge/SQL-000?)
|![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)