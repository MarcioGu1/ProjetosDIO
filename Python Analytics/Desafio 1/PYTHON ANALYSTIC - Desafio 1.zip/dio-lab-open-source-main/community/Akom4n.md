<div align="center"> <h2> Bem vindo ao meu perfil GitHub </h2></div>

<div align="center">
<details>
  <summary>🧑 Sobre mim</summary>

- 🔭 Buscando sempre **aprender e me desenvolver**

- 🌱 Em busca de melhorar e trabalhar com **Java Back-End**

- 💬 Pergunte me sobre **open source, web development, and back-end**

- 📫 Me encontre em **joaovinicius.silva210@gmail.com**

- 👾 Se diante do universo nós somos criaturas insignificantes, a maior vitória que a gente pode ter, é viver uma vida com satisfação...

</details>

</p>

<!--
<details>
  <summary>📕 Blog Posts</summary>
  <br />
</details>
</div>
-->

## GitHub Status

<img align="right" width="40%" src="https://media4.giphy.com/media/8UkaQtVBS2r8Q/giphy.gif?cid=ecf05e47r1um0l7v0gt20g02fepdine2oke6avs0261peop3&ep=v1_gifs_search&rid=giphy.gif&ct=g"/>
<div align="center">
<a href="https://github.com/Akom4n"> <img height="200px" src="https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs?username=akom4n&show_icons=true&locale=en&layout=donut&theme=dracula" alt="Akom4n" />
<a href="https://git.io/streak-stats"><img width="50%" src="https://streak-stats.demolab.com?user=Akom4n&theme=dracula&locale=pt_BR&date_format=M%20j%5B%2C%20Y%5D" alt="GitHub Streak" /></a>
<div align="left">

### Languages <img align="center" width="7%" src="https://media4.giphy.com/media/iJsjsm6dhNPiQBvztq/200w.webp?cid=ecf05e47jc19wtj5p47ikodhz42fdlyiii8psf7699hrlpp6&ep=v1_stickers_search&rid=200w.webp&ct=s" />
<p align="left">
  <a href="https://skillicons.dev">
    <img src="https://skillicons.dev/icons?i=angular,cs,css,java,js,maven,mysql,spring" />
  </a>
</p>

### Tools and Software <img align="center" width="6%" src="https://media2.giphy.com/media/iXlqIloEi4etN1V2Z5/200w.webp?cid=ecf05e47sr3w761ftukbt7bul7zevuzji6j88g6kyo0yihqf&ep=v1_stickers_search&rid=200w.webp&ct=s" />
<p align="left">
  <a href="https://skillicons.dev">
    <img src="https://skillicons.dev/icons?i=docker,eclipse,gamemakerstudio,git,idea,linux,postgres,postman,vim,visualstudio"/>
  </a>
</p>

<!---
Akom4n/Akom4n is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
