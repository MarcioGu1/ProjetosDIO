
#Angelo-Miguel
 
- Olá, Meu nome é Angelo Miguel.

    - Atualmente estou terminando meu tcc
    #Focototal

## Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/angelo-miguel-b36077295/)

## Habilidades

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![PHP](https://img.shields.io/badge/php-000?style=for-the-badge&logo=php)

![C++](https://img.shields.io/badge/C++-000?style=for-the-badge&logo=C++)

