# Sou André Moura✌

Estudante de Dados, formado em Redes

## Vamos nos conectar?

[![Linkedin](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/andrelmoura/)



![André GitHub stats](https://github-readme-stats.vercel.app/api?username=AndreLM28&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Tecnologia que estou estudando e usando atualmente:

<div style="display: inline_block"><br/>
    <img align="center" alt="Python" src="https://img.shields.io/badge/PYTHON-amazonaws?logo=python&labelColor=%23232F3E&color=%23232F3E">
 <img align="center" alt="AWS" src="https://img.shields.io/badge/AWS-amazonaws?logo=amazonaws&labelColor=%23232F3E&color=%23232F3E">
   
</div><br/>


