 # Olá, eu sou Angelo Souza 


 - Acesse meu perfil no [Github](https://github.com/AngeloSouza1)



#### Estatísticas Github 

<img width=55% align="center"  src="https://github-readme-streak-stats.herokuapp.com?user=AngeloSouza1&theme=radical&mode=weekly" />
<img width=40% align="center" src="https://github-readme-stats-iota-five-91.vercel.app/api/top-langs/?username=AngeloSouza1&show_icons=true&theme=radical&layout=compact" 

