### Olá! Dizem que sou o Carlos André 😎

Desenvolvedor de Abreu e Lima-PE, Brasil, formado em Administração de empresas e atualmente estou cursando análise e Desenvolvimento de Sistemas. Meu primeiro "Hello World" foi quando tive contato com HTML e CSS.
Apaixonado por tecnologia, alguns dos meus hobbies são games, séries e cinema.

### Conecte-se comigo

[![Linkedin](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/carlos-andre-4b939819b/)
[![Twitter](https://img.shields.io/badge/Twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white
)](https://twitter.com/Andre_Junior18)
[![Instagram](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/4ndre.jr/)


![](https://github-readme-stats.vercel.app/api?username=Andrejr117&show_icons=true&theme=tokyonight)


## Tecnologias que estudo atualmente 
<div stryle="display: inline_block"><br/>
    <img align="center" alt="html5" src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white"/>
    <img align="center" alt="css3" src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white"/>
    <img align="center" alt="react" src="https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB"/>
    <img align="center" alt="python" src="https://img.shields.io/badge/Python-14354C?style=for-the-badge&logo=python&logoColor=white"/>
    <img align="center" alt="java" src="https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white"/>
    <img align="center" alt="kotlin" src="https://img.shields.io/badge/Kotlin-0095D5?&style=for-the-badge&logo=kotlin&logoColor=white"/>
</div><br/>
