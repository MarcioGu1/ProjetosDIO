# Apresentação

Me chamo Aquiles Oliveira da Silva, tenho 16 anos e estou fazendo este curso da DIO para começar no mundo da programação. Não possuo muita experiência porém já fiz alguns sites usando HTML, CSS e JavaScript na escola. 

# Habilidades 

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)

# Trabalhos já feitos

[Trabalho sobre o livro Dom Casmurro, de Machado de Assis.](https://d0f5595a-dfa3-494f-8a49-da024006dfd5-00-28iypypiu5nk9.global.replit.dev/)

[Trabalho sobre o sistema cardiovascular.](https://3246a204-b2f7-45d6-b546-9346cc07771a-00-13gdw7h0ghqwp.riker.replit.dev/)