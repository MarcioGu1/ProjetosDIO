# Olá! Meu nome é Pedro Henrique Soares.

Sou estudante de Análise e Desenvolvimento de Software na Estácio e sou apaixonado por tecnologia, inovação e música.

# Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/pedrohs07041999/)


## 📚☕ Atualmente estou estudando:
- [![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)](https://web.dio.me/track/bf7abb82-1324-4074-9949-f474a1a911fe)
- ![Angular](https://img.shields.io/badge/Angular-000?style=for-the-badge&logo=angular&logoColor=C3002F)

 <img align="right" alt="GIF" src="https://github.com/abhisheknaiidu/abhisheknaiidu/blob/master/code.gif?raw=true" width="500" height="320" />


