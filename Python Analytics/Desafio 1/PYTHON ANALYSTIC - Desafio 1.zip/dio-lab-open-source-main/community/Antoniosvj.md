# Antonio Sérgio Viana Júnior

## Quem é o Antonio?<br/>
Sou uma pessoa apaixonada em tecnologia que resolveu ir em busca de um sonho. Formado em odontologia com 14 anos de experiência e vários cursos em minha área de formação. Hoje decidido em fazer uma transição de carreira de maneira saudável, pois desde novo inserido neste meio, porém as oportunidades não eram grande de formação na época.

Tenho a orientação religiosa católica, casado e a espera de um filho, pois estamos em fila de adoção. A vida estável, porém o coração chamou para seguir este novo desafio.

Hoje estudante de Ciência da Computação pela Universidade Estácio e procurando aprofundar na área através de cursos, pesquisas e bootcamps. Além dos cursos em área de tecnologia, atualmente estudo inglês em nivel iniciante, mas com muita dedicação.
Sempre gostei de desafios e me motivo muito por eles. Gosto de explorar novas possibilidades.

## Minhas redes sociais
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/Antoniosvj/)
[![GitHub](https://img.shields.io/badge/github-000?style=for-the-badge&logo=github)](https://github.com/Antoniosvj)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/antonio.sergiovj/)
[![Facebook](https://img.shields.io/badge/Facebook-000?style=for-the-badge&logo=facebook)](https://www.facebook.com/antonio.sergiovianajunior/)
[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://www.discord.com/in/Antoniosvj/)

## Habilidades
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=Git)
![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)