# Adenilson Ramos

I am a software engineer with a passion for web and mobile development. I am dedicated to constantly learning and expanding my skill set, and am currently studying HTML, CSS, JavaScript, React, React Native, and Node.js.

## Studying

- HTML, CSS, JavaScript
- Git, Github
- Java, SpringBoot

## Interests

- React, React Native, Node.js
- Flutter, Dart

## Education

- Bachelor's degree in Computer Science from the Federal Rural University of Agreste in Pernambuco

## Contact

Feel free to reach out to me for collaboration or to chat about technology.

- Email: adnramos108@gmail.com
- LinkedIn: [Adenilson Ramos](https://www.linkedin.com/in/adn-ramos/)
- LinkTree: adnramos.github.io/
