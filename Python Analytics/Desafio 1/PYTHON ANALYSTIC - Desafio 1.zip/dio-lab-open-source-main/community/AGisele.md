# Olá, me chamo Gisele!

## Sobre mim
Sou Gisele Araújo, tenho 27 anos, sou formada em Engenharia Sanitária e Ambiental pela Universidade Federal da Bahia e estou em transição de carreira para área Tech. Atualmente curso Tecnólogo em Analise e Desenvolvimento de Sistemas pela Universidade Salvador. Estudo direcionado a Java, OO, Spring Boot e SQL.

## Conecte-se comigo
[![portfolio](https://img.shields.io/badge/my_portfolio-000?style=for-the-badge&logo=ko-fi&logoColor=white)](https://github.com/AGisele)
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/giselecaraujo/)
[![Gmail]("https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white")](mailto:araujocgisele@gmail.com)

<div align="center">
  <img width="49%" height="195px" src= "https://github-readme-stats.vercel.app/api/top-langs/?username=AGisele&layout=compact&theme=tokyonight"/>
</div>