<img src = "dev2.gif" width = "350px" align = "right">

# ❤ Oii, eu sou o Bruno!

  <div id="badges">
  <a href = "https://www.linkedin.com/in/bruno-moreira-680109209/">
    <img src="https://img.shields.io/badge/LinkedIn-blue?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn Badge"/>
  </a>

[![portfolio](https://img.shields.io/badge/my_portfolio-000?style=for-the-badge&logo=ko-fi&logoColor=white)](https://github.com/9Brunodox?tab=repositories)

</div>

Sou um developer iniciante, amo jogar, viajar e muito mais!

- ❤ Estudante de Ciência da computação
- 💙 Amo viajar atrás de novos desafios!
- 👩‍💻 Desenvolvedor back-end, pretendo me tornar fullstack

---

<div>
  <img src="https://github.com/devicons/devicon/blob/master/icons/visualstudio/visualstudio-plain.svg" title="Visual Studio" alt="Visual Studio" width="40" height="40"/>&nbsp;
  <img src="https://github.com/devicons/devicon/blob/master/icons/python/python-original.svg" title="Python" alt="Python" width="40" height="40"/>&nbsp;
  <img src="https://github.com/devicons/devicon/blob/master/icons/csharp/csharp-original.svg" title="C#" alt="CSharp" width="40" height="40"/>&nbsp;
  <img src="https://github.com/devicons/devicon/blob/master/icons/html5/html5-original.svg" title="HTML5" alt="HTML" width="40" height="40"/>&nbsp;
  <img src="https://github.com/devicons/devicon/blob/master/icons/javascript/javascript-original.svg" title="JavaScript" alt="JavaScript" width="40" height="40"/>&nbsp;
  <img src="https://github.com/devicons/devicon/blob/master/icons/css3/css3-original.svg" title="css" alt="CSS" width="40" height="40"/>&nbsp;
  <img src="https://github.com/devicons/devicon/blob/master/icons/java/java-original-wordmark.svg" title="Java" alt="Java" width="40" height="40"/>&nbsp;
</div>

---

<div align = "left">
<img height = "200em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=9Brunodox&show_icons=true&theme=aura&count_private=true"/>
<img height = "200em" src="https://github-readme-stats.vercel.app/api?username=9Brunodox&show_icons=true&show_icons=true&theme=aura&count_private=true" />
</div>
