# Adrizaias

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/adrizaias-oliveira-8999a7198/)

## Habilidades
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![Angular](https://img.shields.io/badge/Angular-000?style=for-the-badge&logo=angular&logoColor=C3002F)
## Sobre mim
Estou iniciando minha carreira na areá tecnologica.
Sou formado em Ciências Contabeis e quero desenvolver habilidades tecnologicas para somar a minha carreira profissional.