# Sobre Mim
Eu sou um programador iniciante estudando Engenharia da Computação. Tenho interesse tanto em frontend quanto em backend e estou sempre disposto a aprender novas tecnologias.



## Conecte-se comigo
- GitHub: [ALAN SOUSA](https://github.com/ALAN-SOUSA)



## Habilidades Técnicas
![Python](https://img.shields.io/badge/Python-blue?style=for-the-badge&logo=python&logoColor=white) ![JavaScript](https://img.shields.io/badge/JavaScript-blue?style=for-the-badge&logo=javascript&logoColor=white)
![HTML](https://img.shields.io/badge/HTML-blue?style=for-the-badge&logo=html5&logoColor=white) ![CSS](https://img.shields.io/badge/CSS-blue?style=for-the-badge&logo=css3&logoColor=white)
![Git](https://img.shields.io/badge/Git-blue?style=for-the-badge&logo=git&logoColor=white)
