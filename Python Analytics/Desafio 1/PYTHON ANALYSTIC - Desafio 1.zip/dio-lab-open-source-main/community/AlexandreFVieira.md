# Bem-vindo ao Meu Repositório

Olá, eu sou o Alexandre! 👋

## Sobre mim

- 🌱 Atualmente estou aprendendo JavaScript.
- 👯 Estou procurando colaborar em projetos interessantes.
- 💬 Pergunte-me sobre [Inglês e Automação].
- 📫 Como me encontrar: falecomalex204@gmail.com / insta: @alexandref.vieira.

## Contato

- [LinkedIn](https://www.linkedin.com/in/alexandre-farias-vieira-4882a3249?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app)
- [Email](falecomalex204@gmail.com)

