# ❓ Sobre mim | About me  #

Olá , me chamo Felipe , mas também sou conhecido como ArtyX, perfil que uso em diferentes comunidades , seja na DIO, discord e até na Steam . Já trabalhei com alguns projetos usando stack front (HTML,CSS, JS, React , TailWind) , Java Stack ( Java + Spring + MVC)  mas me encontrei mesmo no backend quando começei a trabalhar com MongoDB, Node + Express, Python .

 Tenho interesse em Data Science , Cloud Services , QA , DevOps , C# mas nada que me impossibilite de trilhar outros caminhos .

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/felipe-e-cardoso/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/ArtyX7)

<br>

# 💪🏻 Habilidades | Skills

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python) 
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)

<br>

# 📚 Aprendendo | Learning
  
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)
![Linux](https://img.shields.io/badge/Linux-000?style=for-the-badge&logo=linux&logoColor=FCC624)


<br> 

 | <h2> 📊 Stats </h2> ||
 |---|---|
 |![GitHub Stats](https://github-readme-stats.vercel.app/api?username=artyX7&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)| <br>![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=ArtyX7&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF) |   
 