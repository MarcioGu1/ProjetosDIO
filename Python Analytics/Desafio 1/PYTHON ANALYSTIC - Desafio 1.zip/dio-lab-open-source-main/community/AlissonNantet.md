# Alisson Nantet

# Infos
- 📆 19 Anos
- 🏠 Jerônimo Monteiro/ES
- 🖥 Formado em Técnico de Informático pelo IFES

    [![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/alissonnantetr/) [![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red)](mailto:alissonnantetr@gmail.com) [![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AlissonNantet)

# Cursando

![Angular](https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white) ![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black) ![MySQL](https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white) ![R](https://img.shields.io/badge/R-276DC3?style=for-the-badge&logo=r&logoColor=white)



# Git Status

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlissonNantet&theme=transparent&bg_color=0000&border_color=F0E68C&show_icons=true&icon_color=F0E68C&title_color=FFD700&text_color=F0E68C)

# Git Streak

[![GitHub Streak](https://streak-stats.demolab.com/?user=AlissonNantet&theme=great-gatsby&background=0000&border=F0E68C&dates=FFF)](https://git.io/streak-stats)