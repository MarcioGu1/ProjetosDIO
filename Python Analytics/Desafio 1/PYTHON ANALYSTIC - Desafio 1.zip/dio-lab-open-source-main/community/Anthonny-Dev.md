
# Anthonny de Mendonça Vitoriano

Meu nome é Anthonny de Mendonça Vitoriano , tenho 19 anos, atualmente estou Cursando Análise e Desenvolvimento de Sistemas, pretendo futuramente me tornar um Desenvolvedor FullStack. Estou a Procura de uma vaga de Estágio na área de Desenvolvimento de Software, ainda estou em processo de Aprendizagem.

Tenho aprimorado minhas habilidades através de Cursos Gratuitos, BootCamps, ChatGPT e conteúdos disponíveis na Internet.


## 📚 Skills
- ![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
- ![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white)
- ![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
- ![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
- ![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
- ![C](https://img.shields.io/badge/C-00599C?style=for-the-badge&logo=c&logoColor=white)
- ![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)

- [![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Anthonny-Dev)


##  👥 Social 
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/anthonny-de-mendon%C3%A7a-vitoriano-540180276/)

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Anthonny-Dev)

[![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red)](mailto:anthonnyvitoriano23@gmail.com)s