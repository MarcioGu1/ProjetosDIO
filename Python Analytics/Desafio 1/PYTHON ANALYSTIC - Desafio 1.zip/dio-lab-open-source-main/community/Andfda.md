<h1> Olá, eu sou o Anderson 👋🏽</h1> 

<img align="center" alt="Developer vector created by storyset - www.freepik.com" height="250" src="https://img.freepik.com/vetores-gratis/ilustracao-do-conceito-de-controle-de-versao_114360-3249.jpg?w=826&t=st=1699506485~exp=1699507085~hmac=4fc389bb10d2030e94b3b7160dc8eded1e85cdf40b2b9e83a2d12615a72f8fa9"> 
 
<p aling ="center"> Olá meu nome é Anderson Antonio Lustosa Ribeiro da silva, tenho 33 anos, sou estudante de Análise e Desenvolvimento de Sistesmas, em constante busca de conhecimmento para me desenvolver e conquistar minha mudança na área profissional.
</p> <br><br>

<h2> Conecte-se comigo </h2>

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000000?style=for-the-badge)](https://www.dio.me/users/andfda)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=efb810)](mailto:andfda@yahoo.com.br)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/anderson-silva-8a3a50206/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/and_fda/)
[![WhatsApp](https://img.shields.io/badge/WhatsApp-000000?style=for-the-badge&logo=whatsapp&logoColor="")](https://wa.me/5583986223013_WHATSAPP)

<h2> Habilidades </h2>

![HTML5](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=30A3DC)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=E94D5F)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)


<h2> GitHub Stats </h2>

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Andfda&theme=transparent&bg_color=000&border_color=A3DC&show_icons=true&icon_color=efb810&title_color=efb810&text_color=FFF)<br>

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Andfda&bg_color=000&border_color=30A3DC&title_color=efb810&text_color=FFF)

<h2> GitHub Streak Stats </h2>

[![GitHub Streak](https://streak-stats.demolab.com/?user=Andfda&theme=slateorange&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)
