# Arthur C. Frederico

## Sobre mim
Meu nome é Arthur, tenho 31 anos, sou de Teresópolis, RJ. 
Atualmente cursando Tecnologo em Analise e Desenvolvimento de sistemas na Estacio.
Estou em transicao de carreira para TI.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/arthur-frederico-1b169a1bb/)

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/ArthurCFred)

[![WhatsApp](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/5521995339740)

## Github Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=ArthurCFred&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=ArthurCFred&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

[![GitHub Streak](https://streak-stats.demolab.com/?user=ArthurCFred&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)

## Linguagens de Marcação e Estilo

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)

## Linguagens de Programação
![C++](https://img.shields.io/badge/C%2B%2B-00599C?style=for-the-badge&logo=c%2B%2B&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)

## Ferramentas
![Vscode](https://img.shields.io/badge/Vscode-007ACC?style=for-the-badge&logo=visual-studio-code&logoColor=white)

![ChatGPT](https://img.shields.io/badge/ChatGPT-%231A9A7A?style=flat-square&labelColor=%23414141&logo=openai&logoColor=white)

## Tecnologias e ferramentas que estou estudando:

![Angular](https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white)
![AWS](https://img.shields.io/badge/AWS-000.svg?style=for-the-badge&logo=amazon-aws&logoColor=white) 

## Formacoes e cursos que estou fazendo
Cybersecurity --> Hackers do Bem

Desenvolvedor Fullstacker Java --> EBAC

Desenvolvimento Front-End com Angular --> DIO 

Inteligencia Artificial Aplicada a visao computacional --> QUALIFACTI
