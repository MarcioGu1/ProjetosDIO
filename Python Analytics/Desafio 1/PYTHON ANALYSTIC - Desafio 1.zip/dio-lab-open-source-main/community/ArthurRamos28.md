[![Typing SVG](https://readme-typing-svg.herokuapp.com?duration=5000&pause=60&color=CFCECB&center=falso&vCenter=falso&lines=👋+Olá+sou+o+Arthur+Ramos;+Hi,+I'm+Arthur+Ramos;)](https://git.io/typing-svg)
<h1>
    <a href="https://web.dio.me/users/arthur_framos?tab=skills&page=1">
     <img align="center" width="40px" src="https://hermes.digitalinnovation.one/assets/diome/logo-minimized.png">
 Arthur Ramos
</a>
</h1>
  <h2><strong>Biografia sobre mim / Biography about me:</strong></h2>
    <p>
      Sou um programador de 31 anos, autodidata, focado. Sempre me destaquei na área da tecnologia, mas somente aos 
      29 anos com o apoio da minha Família (Esposa e filhos), comecei a estudar programação e, desde então, me dedico cada vez mais para aumentar minhas habilidades. Ainda estou na fase inicial, estou um pouco mais de 1 ano no mercado como programador. Atualmente trabalho com Delphi, SQL, Postman e API, ainda bem na fase inicial, mas venho me dedicando para entrar na área web, para uma formação FullStack.
    </p>
    <p>
      I'm a 31-year-old, self-taught, focused programmer. I have always stood out in the technology field, but only at the age of 29, with the support of my Family (Wife and children), I started studying programming and, since then, I have dedicated myself more and more to increasing my skills. I'm still in the initial phase, I've been on the market for a little over 1 year. I currently work with Delphi, SQL, Postman and API, still well in the It's still  initial phase, but I've been dedicating myself for entering area  FullStack Web.
    </p>   

  <h2>
    <strong>Minha formação acadêmica / My academic background:</strong>
  </h2>
    <p>Ensino Medio / High School - Completo / Complete;</p>
  <h2>
    <strong>Cursos / Courses:</strong>
   </h2>
  <ul>
    <li>Inglês Básico - Influx;</li>
    <li>Git e GitHub do zero ao avançado - Udemy;</li>
    <li>Curso Completo de Banco de Dados SQL - Udemy;</li>
    <li>Postman Iniciante - Udemy;</li>
    <li>Programação Python do Zero ao Avançado - Udemy;</li>
    <li>Delphi do Inicio ao Fim - Academia do Código;</li>
    <li>Inglês Essencial para Profissional de T.I - Udemy;</li>
    <li>Desenvolvimento Web Full Stack com Python e Django - Udemy;</li>
    <li>Desenvolver Sistema com Delphi e SQLServer na PRÁTICA - Udemy;</li>
    <li>Sistema de Pedidos Delphi - Pedidos e Controle de Mesas - Udemy;</li>
    <li>Inglês Open English - Em Andamento;</li>
  </ul>

<h2><strong>Soft Skills</strong></h2>
  <ul>
    <li>Trabalho em equipe / Team work</li>
    <li>Motivação / Motivation;</li>
    <li>Resiliênte / Resilient;</li>
    <li>Flexibiliade / Flexibility;</li>
    <li>Versátil / Versatile;</li>
    <li>Confiável / Reliable;</li>
  </ul>    

<h2><strong>Hard Skills</strong></h2>

<p>Intermediário / Intermediary:</p>

![Delphi](https://img.shields.io/badge/Delphi-000?style=for-the-badge&logo=Delphi)


 <p>Iniciante / Beginner:</p>

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![Postman](https://img.shields.io/badge/Postman-000?style=for-the-badge&logo=Postman)
![Angular](https://img.shields.io/badge/Angular-000?style=for-the-badge&logo=Angular)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=Python)

<div>
<a href="https://github.com/ArthurRamos28">
<img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=arthurramos28&layout=compact&langs_count=7&theme=dracula"/>
<img height="180em" src="https://github-readme-stats.vercel.app/api?username=arthurramos28&show_icons=true&theme=dracula&include_all_commits=true&count_private=true"/>
</div>

<h2><strong>Conecte-se comigo / Connect with me:</strong></h2>

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/arthur_framos/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](arthur.framos@hotmail.com)
[![Instagram](https://img.shields.io/badge/Instagram-%23E4405F.svg?style=for-the-badge&logo=Instagram&logoColor=white)](https://www.instagram.com/arthurframos27/)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.instagram.com/arthurframos27/)

#
<p align="right">
  <img src="https://visitor-badge.laobi.icu/badge?page_id=arthurramos28.arthuramos28" alt="visitors">
</p>  