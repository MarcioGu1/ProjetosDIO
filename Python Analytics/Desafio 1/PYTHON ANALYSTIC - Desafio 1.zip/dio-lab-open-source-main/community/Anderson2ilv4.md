# 💻Anderson Silva


I'm a self-taught software engineer, I'm getting a degree in a software engineering course but it's online, and if I want to learn, I have to study hard by myself, I'm creating some content on [LinkedIn](https://www.linkedin.com/in/anderson-silva-717179166/), [Instagram](https://www.instagram.com/anderson_josse/) and recently I started creating some content on [YouTube](https://www.youtube.com/channel/UCVT2PoI_I8i9HQjYfFFwTMA) too, I don't want to be famous but it's a way that I use to practice and learn something, when I try to teach something I'm able to get some more expertise on that, so that is the reason I'm creating, if some company find me by that it would be good, so take a look at my GitHub profile!! 

## 🧳Languages and Tools

<img src="/assets/python.svg" align="left" style="width:50px;"><img src="/assets/c.svg" align="left" style="width:50px;"><img src="/assets/php.svg" align="left" style="width:50px;"><img src="/assets/git.svg" align="left" style="width:50px;"><img src="/assets/html.svg" align="left" style="width:50px;"><img src="/assets/css.svg" align="left" style="width:50px;"><img src="/assets/js.svg" align="left" style="width:50px;"><img src="/assets/bash.svg" style="width:50px;">

# 🎬YouTube videos comming soon ⏳

<details>
    <summary><h1>👨‍💻Anderso'n coding journey</h1></summary>
    <p>Hi, I'm Anderson, here we have a little part of my journey on coding, my first time coding was on 2017, when I graduated from high school, I just started a course that had python as the main language, and it was my first language, very simple to learn and so powerfull, when I finished my course I stayed for a long time without coding anything, trying to get on diferent areas like stocks exchange, but I was always in contact with computers and when the stocks didn't work for me I started again studying about coding, learning diferent languages and being more interested on that subject, it's because with it I can resolve some real problems to other people, I think that it was the reason that I didn't fit in stocks exchange market, because I was just resolving my problems and what I want is to help people, so since November, 2022 I'm daily studying and getting more knowledge and I won't stop till I acheave my goas, I'm not a tative english speaker, sorry if a made some mistakes.</p>
</details>