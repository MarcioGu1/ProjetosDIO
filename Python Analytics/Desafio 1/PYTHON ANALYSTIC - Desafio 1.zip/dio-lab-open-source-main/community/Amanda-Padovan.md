
# Amanda Padovan

Olá, sou formada em Publicidade e Propaganda desde 2014, funcionária pública na área de Recursos Humanos há 9 anos e estou em transição de carreia, cursando o primeiro semestre de bacharelado em Tecnologia da Informação na UNIVESP.
Também sou interessada em livros, criei o instagram Nerdíssimos, onde falo da minha paixão.

## Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/amanda-padovan-6069b030/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/mandahpadovan/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/nerdissimos/)

