# Alecruzt 

Olá sou uma estudante de Desenvolvimento Full Stack pela Estácio.

Também aprendendo novas linguagens de programação pela DIO.

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alessandra-cruz-84a73b165/)

[![GitHub](https://img.shields.io/badge/GitHbt-000?style=for-the-badge&logo=github&logoColor=white)](+https://github.com/Alecruzt)

