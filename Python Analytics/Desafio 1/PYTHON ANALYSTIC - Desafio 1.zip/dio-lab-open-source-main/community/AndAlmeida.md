### Olá, eu sou o Andrew, desenvolvedor web fullstack!
#
<p>
Desenvolvedor recém formado, minha paixão por softwares reside na possibilidade de tornar ideias em realidade através da programação e como tais ideias podem moldar uma sociedade.  
</p>

> “Low expectations are a self-fulfilling prophecy. If we aim high, we’ll get better results.”
― Ted Chiang, Exhalation
#
### 🏫 Education
* Pós-graduação em Desenvolvimento Web Fullstack | (Anhanguera Educacional-AM)<br/>
* Superior de Tecnologia em Análise e Desenvolvimento de Sistemas | (UNIP-AM)<br/>
* Técnico em Manutenção e Suporte em Informatica | (IFAM-AM)<br/>

### 📚 Learnings and Hobbies
* Atualmente estou estudando sobre Frameworks Web, com foco no Java Spring Boot, como funciona o gerenciamento de eventos simplificado, validação, ligação de dados, conversão de tipo e segurança integrada e recursos de teste;
* Aficionado em 🎮 Games e 🎞️ filmes. Especialmente, sci-fi e terror, e em hard rock setentista e alternative rock.
* Costumo ler bastante livros de fantasia e space opera.

<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

### 🖥️ Technologies and Skills
<div style="display: inline-block"><br/>
    <img align="Center" alt="HTML5" src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white">
    <img align="Center" alt="CSS3" src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white">
    <img align="Center" alt="JavaScript" src="https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E">
    <img align="Center" alt="Java" src="https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white">
    <img align="Center" alt="PHP" src="https://img.shields.io/badge/PHP-777BB4?style=for-the-badge&logo=php&logoColor=white">
    <img align="Center" alt="Angular" src="https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white">
    <img align="Center" alt="Spring" src="https://img.shields.io/badge/Spring-6DB33F?style=for-the-badge&logo=spring&logoColor=white">
    <img align="Center" alt="MySql" src="https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white">
    
</div>
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">

### ⚙️ Github Analytics
![Andrew GitHub stats](https://github-readme-stats.vercel.app/api?username=AndAlmeida&show_icons=true&theme=tokyonight)
![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=AndAlmeida&layout=compact&theme=tokyonight)
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">


### 📱 Connect with Me

[![E-mail](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](andalmeida77@gmail.com)