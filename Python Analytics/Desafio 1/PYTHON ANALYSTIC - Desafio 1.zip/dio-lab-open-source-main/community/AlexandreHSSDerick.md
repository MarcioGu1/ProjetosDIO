# Alexandre (Derick)

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=White)](https://www.linkedin.com/in/alexandre-henrique-dos-santos-silva-12b385119/)
[![Hackerrank](https://img.shields.io/badge/-Hackerrank-000?style=for-the-badge&logo=HackerRank&logoColor=white)](https://hackerrank.com/profile/@alexandreorderi1)

## Habilidades
![Python](https://img.shields.io/badge/python-000?style=for-the-badge&logo=python&logoColor=fff)
![Azure](https://img.shields.io/badge/Azure-black?style=for-the-badge&logo=microsoft%20azure&logoColor=white&labelColor=000&link=https%3A%2F%2Fimages.app.goo.gl%2FK7PN1jYJd57x4q7A8)
![Windows](https://img.shields.io/badge/Windows-000?style=for-the-badge&logo=windows&logoColor=fff)
![Linux](https://img.shields.io/badge/Linux-000?style=for-the-badge&logo=linux&logoColor=fff)
![Git](https://img.shields.io/badge/GIT-000?style=for-the-badge&logo=git&logoColor=white)
![Figma](https://img.shields.io/badge/Figma-000?style=for-the-badge&logo=figma&logoColor=white)
![Vscode](https://img.shields.io/badge/Vscode-000?style=for-the-badge&logo=visual-studio-code&logoColor=white)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlexandreHSSDerick&theme=transparent&bg_color=000&border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=FFF)


![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AlexandreHSSDerick&layout=compact&bg_color=000&border_color=fff&title_color=fff&text_color=FFF)


## Minhas Contribuições
[![GitHub Streak](https://streak-stats.demolab.com/?user=AlexandreHSSDerick&theme=bear&background=000&border=fff&dates=FFF)](https://git.io/streak-stats)
