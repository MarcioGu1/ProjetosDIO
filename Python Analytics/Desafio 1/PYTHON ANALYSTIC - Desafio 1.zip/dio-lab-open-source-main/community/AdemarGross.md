# Ademar Gross

Engenheiro Civil em transição de carreira para tecnologia!

### Me encontre

<div align="left" >
  <h3>Contatos</h3>
<a href="https://www.linkedin.com/in/ademar-gross/" onclick="window.open(this.href); return false;">
  <img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white">
</a> 
<a href="mailto:ademar.gross@gmail.com" onclick="window.open(this.href); return false;">
  <img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white">
</a>

</div>


### Habilidades

![HTML5](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=30A3DC)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=E94D5F)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=30A3DC)

[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)]()
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)]()


##
### 📊 Estatísticas no GitHub:
<a href="https://github.com/AdemarGross">
  <img height=200 align="center" src="https://github-readme-stats.vercel.app/api?username=AdemarGross&locale=pt-br&show_icons=true&include_all_commits=true&count_private=true&\&rank_icon=github" />
</a>
