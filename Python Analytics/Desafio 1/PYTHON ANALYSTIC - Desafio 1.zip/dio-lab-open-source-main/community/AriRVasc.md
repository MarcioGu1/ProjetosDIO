## Hello World! 👋

## Sobre mim
Olá! Meu nome é Ariadne Rodrigues Vasconcelos, sou estudante de Engenharia de Software e possuo formação no curso de Desenvolvimento Web Full Stack, com conhecimentos em Java e Python para análise de dadosgit . Atualmente, faço parte da equipe de Engenharia de Dados na Serasa Experian, onde trabalhamos com uma ampla gama de tecnologias, incluindo:

- Python
- PHP
- SQL
- Git/Github
- Ecossistema Hadoop (Hbase, Kafka, HDFS)
- Jenkins


Estou em constante aprendizado nessa nova jornada profissional, explorando diversas tecnologias e adquirindo habilidades adicionais. Além disso, em nosso ambiente de trabalho, utilizamos a metodologia ágil **SCRUM** para otimizar nossos processos e entregar resultados de forma eficiente. Buscando constantemente aprimorar minhas habilidades profissionais, também dedico tempo às aulas de inglês, reconhecendo sua importância fundamental na área de Tecnologia da Informação.

## Meus projetos
Em meu repositório, você encontrará projetos relacionados a Engenharia de Dados, Desenvolvimento Web e muito mais.
- Github: [AriRVasc](https://github.com/AriRVasc)

## Contato
- LinkedIn: [Ariadne Rodrigues Vasconcelos](https://www.linkedin.com/in/devari)
- Email: djari.code@gmail.com
  