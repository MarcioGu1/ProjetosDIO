# Adriana Campos

 Olá! Estou aprimorando meus conhecimentos como estudante de Análise e Desenvolvimento de Sistemas. Acredito no poder do trabalho em equipe e estou ansiosa para colaborar em projetos que unam minha experiência em DP com as inovações tecnológicas da atualidade.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/adriana-campos-016801198//)

[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=GitHub&logoColor=0E76A8)](https://github.com/AdrianaCCampos)

## Habilidades
[![GitHub](https://img.shields.io/badge/GitHub-ec63a1?style=for-the-badge&logo=github&logoColor=fff)](https://docs.github.com/)

[![Git](https://img.shields.io/badge/Git-ec63a1?style=for-the-badge&logo=git&logoColor=fff)](https://git-scm.com/doc)

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AdrianaCCampos&theme=transparent&bg_color=ec63a1&border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=fff&hide_title=true&hide=stars)

## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AdrianaCCampos&repo=dio-lab-open-source&bg_color=ec63a1&border_color=fff&show_icons=true&icon_color=fff&title_color=fff&text_color=fff)](https://github.com/AdrianaCCampos/dio-lab-oprn-source)
