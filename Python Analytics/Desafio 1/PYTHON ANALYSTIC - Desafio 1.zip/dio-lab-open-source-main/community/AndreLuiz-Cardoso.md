Olá tudo bem? vou deixar um enigma auhauah
Si vous pouvez lire ce texte, ajoutez-moi sur LinkedIn
https://www.linkedin.com/in/andre-l-cardoso/