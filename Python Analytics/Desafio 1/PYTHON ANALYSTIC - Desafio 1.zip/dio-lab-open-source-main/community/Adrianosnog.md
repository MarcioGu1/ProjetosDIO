# Adriano Nogueira

Atualmente trabalho com Teste de Softawares e é neste caminho que pretendo seguir carreira, recém formado em Análise e Desenvolvimento de Sistemas, ainda sou iniciante na profissão..

## Algumas Habilidades:

https://robotframework.org/

https://www.selenium.dev/

## Conhecimentos Básicos:

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)

Lógica de programação entre outros conhecimentos básicos..

Meu Git:

[![GitHub](https://img.shields.io/badge/GitHbt-000?style=for-the-badge&logo=github&logoColor=white)](+https://github.com/Adrianosnog)
