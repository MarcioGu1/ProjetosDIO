# 👦 Hi!
<p align="center">
✌ Hello, I'm Andrey, a programming stundent
</p>

## 🧠 About Me
* Andrey de Jesus
* 21 years
* Currently studying Java and Python
* Rio de Janeiro, RJ
  
 ## *💬 My skills:*
<details>
  
  <summary>My Languagues</summary>
 
  > ![C](https://img.shields.io/badge/C-00599C?style=for-the-badge&logo=c&logoColor=white)
  ![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=black)
  ![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
  ![C++](https://img.shields.io/badge/C%2B%2B-00599C?style=for-the-badge&logo=c%2B%2B&logoColor=black)
  
</details>

<details>
  <summary>Versioning</summary>
   
   > ![Git](https://img.shields.io/badge/git-%23F05033.svg?style=for-the-badge&logo=git&logoColor=white) 
  ![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white)
  
</details>

## *💻 You Can Find Me On:*
 [![X](https://img.shields.io/badge/X-000?style=for-the-badge&logo=x)](https://x.com/Andy_J19)
 [![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/andreyj19/)
 [![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/Andreyj19)
 [![WhatsApp](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/+5521999003310)
 [![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=007BFF)](mailto:Andreyjcw@hotmail.com)
 [![Gmail](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:Andreyjcw@gmail.com)
 
 *Click on the image above to be redirected*
 #
<div> 

  ![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Andreyj19&theme=midnight-purple)
  ![GitHub Streak](https://streak-stats.demolab.com/?user=Andreyj19&theme=midnight-purple)
  
</div>

