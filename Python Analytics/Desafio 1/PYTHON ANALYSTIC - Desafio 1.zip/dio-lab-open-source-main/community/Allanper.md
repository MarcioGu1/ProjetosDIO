<h1 align="center">
    <a href="https://www.linkedin.com/in/allanper/">
     <img align="center" width="100px" src="C:\Users\linda\OneDrive\Área de Trabalho\DIO\BootCamp - Angular-Java">
    </a>
    <br />
    Olá, eu sou Allan Pereira!
</h1>

<p align="center">
                            "Open to contact for participation in the development of research in various technological areas."

                                       "Technology, environment, and humanity together."

I seek to evolve in my professional career, always opening new paths for new projects. I am constantly studying new concepts and technologies in different areas of technology.

Areas of research interest:

-Nanotechnology
-Blockchain
-Artificial intelligence 
-Software development
-Intersection of law and psychology in technology"
</p>

<p align="center">
    <a href="https://www.linkedin.com/in/allanper/">
        <img src="https://img.shields.io/badge/-LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white" />
    </a>
    <a href="mailto:allanmarp@hotmail.com">
        <img src="https://img.shields.io/badge/-Email-D14836?style=for-the-badge&logo=microsoft-outlook&logoColor=white" />
    </a>
</p>

### Soft Skills

![Capacidade de Adaptação](https://img.shields.io/badge/Capacidade%20de%20Adaptação-30A3DC?style=for-the-badge)
![Habilidades Analíticas](https://img.shields.io/badge/Habilidades%20Anal%C3%ADticas-E94D5F?style=for-the-badge)
![Comunicação Interpessoal](https://img.shields.io/badge/Comunicação%20Interpessoal-181717?style=for-the-badge)

### Hard Skills

![C#](https://img.shields.io/badge/C%23-239120?style=for-the-badge&logo=c-sharp&logoColor=white)
![Java](https://img.shields.io/badge/Java-007396?style=for-the-badge&logo=java&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![HTML](https://img.shields.io/badge/HTML-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS](https://img.shields.io/badge/CSS-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![Microsoft SQL Server](https://img.shields.io/badge/Microsoft%20SQL%20Server-CC2927?style=for-the-badge&logo=microsoft-sql-server&logoColor=white)
![Blazor](https://img.shields.io/badge/Blazor-5C2D91?style=for-the-badge)
![Node.js](https://img.shields.io/badge/Node.js-339933?style=for-the-badge&logo=node.js&logoColor=white)
![Express.js](https://img.shields.io/badge/Express.js-000000?style=for-the-badge&logo=express&logoColor=white)
![RESTful APIs](https://img.shields.io/badge/RESTful%20APIs-30A3DC?style=for-the-badge)
![Angular](https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white)
![Scrum](https://img.shields.io/badge/Scrum-30A3DC?style=for-the-badge)
![Git](https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=git&logoColor=white)
![Tortoise SVN](https://img.shields.io/badge/Tortoise%20SVN-810B14?style=for-the-badge&logo=apache-subversion&logoColor=white)
![Blockchain](https://img.shields.io/badge/Blockchain-121D33?style=for-the-badge)
![Smart Contracts](https://img.shields.io/badge/Smart%20Contracts-FFA63D?style=for-the-badge)
![Decentralized Apps (DApps)](https://img.shields.io/badge/Decentralized%20Apps%20(DApps)-0A66C2?style=for-the-badge)

### GitHub Stats

<p align="center">
  <img src="https://github-readme-stats.vercel.app/api?username=Allanper&theme=dark&show_icons=true&count_private=true" alt="GitHub Stats">
  <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span> <!-- Adiciona espaço entre as badges -->
  <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=Allanper&layout=compact" alt="Top Languages">
</p>

### Meus Principais Projetos

Programacao-JavaScript(https://github-readme-stats.vercel.app/api/pin/?username=Allanper&repo=nome-do-projeto-1&theme=dark)](https://github.com/Allanper/Programacao-JavaScript)

dio-lab-open-source(https://github-readme-stats.vercel.app/api/pin/?username=Allanper&repo=nome-do-projeto-2&theme=dark)](https://github.com/Allanper/dio-lab-open-source)

### Meus Artigos

- "Adoção de Blockchain para Certificações em Normas de Gestão ISO" (em desenvolvimento)
