<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=DAA520&height=120&section=header"/>

[![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=DAA520&size=35&center=true&vCenter=true&width=1000&lines=Nice+to+meet+you,+my+name+is+Abdoral+Neto;Welcome+to+my+GitHub+Profile!:%29)](https://git.io/typing-svg)

### GitHub Stats

<div style="display: flex;
">

<img height="150rem" src="https://github-readme-stats.vercel.app/api?username=AbdoralNeto&show_icons=true&theme=dark&title_color=BDB76B&text_color=F0FFFF&icon_color=DAA520&border_color=8FBC8F">

<img src="https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AbdoralNeto&layout=compact&theme=dark&border_color=8FBC8F&title_color=BDB76B&text_color=F0FFFF">
</div>

## Contribuition Chart

<div class="Panel-Contribuition">
    <div>
    <img height="150rem" src="https://github-readme-activity-graph.vercel.app/graph?username=AbdoralNeto&bg_color=000000&color=F0FFFF&line=f0ffff&point=ff0000&area=true&hide_border=true)](https://github.com/ashutosh00710/github-readme-activity-graph"/>
    </div>
</div>

## Learning

[<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original-wordmark.svg" height=30 width=30 />](https://docs.oracle.com/javase/8/docs/api/)[**Java**](https://docs.oracle.com/javase/8/docs/api/)

[<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/angularjs/angularjs-original.svg" height=20 width=20/>](https://angular.io/docs)   [**Angular**](https://angular.io/docs)
          
[<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg" height=20 width=20/>
](https://git-scm.com/doc)[**Git**](https://git-scm.com/doc)

<!--## Contribuição
![Snake animation](https://github.com/AbdoralNeto/AbdoralNeto/blob/output/github-contribution-grid-snake.svg)
-->

#### More
_______
<div align="center">

[![Telegram](https://img.shields.io/badge/Telegram-000?style=for-the-badge&logo=telegram&logoColor=0)](t.me/F4lcao)[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://www.discord.com/in/SEUUSERNAME/)[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/SEUUSERNAME/)[![Twitter](https://img.shields.io/badge/Twitter-000?style=for-the-badge&logo=twitter)](https://twitter.com/SEUUSERNAME)
</div>

<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=DAA520&height=120&section=footer"/>