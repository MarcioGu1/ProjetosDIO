
# Hey, I'm Felipe Augusto

Tech student, enthusiast of any theme that involves constant learning. Get to know me more and what I'm studying now on my [![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/felipe-augusto-3b651184/)

## 📃 Certificates

- [Trabalhando em Equipes Ágeis](https://www.dio.me/certificate/49F065D6/share)
- [Versionamento de Código com Git e GitHub](https://www.dio.me/certificate/AE4D868E/share)

## 💻 Skills

| Ferramenta | Qualificação |
|------|---------|
| ![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black) | [Presentation]() |
| ![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white) | [Example with applied design]() |
| ![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white) | [Machine house]() |

## ⚒️ Most used tools

![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)
![Vscode](https://img.shields.io/badge/Vscode-007ACC?style=for-the-badge&logo=visual-studio-code&logoColor=white)


## 🏫 Courses

- Potencial Tech iFood - Programação do Zero - [Digital Inovation One](https://www.dio.me/en);
- Javascript - [Curso em Vídeo](https://www.cursoemvideo.com/);
- CS 50 - [Harvard's edX](https://learning.edx.org/course/course-v1:HarvardX+CS50+X/home).
