# Agatha Freitas

Olá, eu sou a Agatha Freitas estudante de ADS e futura Dev Junior ;D

## Conecte-se Comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-FFF?style=for-the-badge&logo=linkedin&logoColor=FFCBDB)](https://www.linkedin.com/in/agatha-freitas-1b3bb6212/) [![Discord](https://img.shields.io/badge/Discord-FFF?style=for-the-badge&logo=discord&logoColor=FFCBDB)](https://www.discord.com/in/hta_tatha/)

## Habilidades - Linguagens de Marcação e Estilo

![Markdown](https://img.shields.io/badge/Markdown-FFF?style=for-the-badge&logo=markdown&logoColor=FFCBDB)![HTML5](https://img.shields.io/badge/HTML5-FFF?style=for-the-badge&logo=html5&logoColor=FFCBDB)![CSS3](https://img.shields.io/badge/CSS3-FFF?style=for-the-badge&logo=css3&logoColor=FFCBDB)

## Habilidades - Linguagens de Programação

![JavaScript](https://img.shields.io/badge/JavaScript-FFF?style=for-the-badge&logo=javascript&logoColor=FFCBDB)

## Habilidades - Extras

![GitHub](https://img.shields.io/badge/git-FFF?style=for-the-badge&logo=git&logoColor=FFCBDB)
![JavaScript](https://img.shields.io/badge/GitHub-FFF?style=for-the-badge&logo=GitHub&logoColor=FFCBDB)

## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AgathaNFreitas&theme=transparent&bg_color=FFF&border_color=000&show_icons=true&icon_color=000&title_color=000&text_color=FFCBDB)
