# - 👋 Olá, eu sou o Rodrigo!

- Sou um novato, gosto de programar e estou aprendendo muito na área. Tenho bastante interesse em Front-end. 

## Conecte-se Comigo
[![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=Github&logoColor=0E76A8)](https://github.com/1rods/) 

[![Linkedin](https://img.shields.io/badge/Linkedin-000?style=for-the-badge&logo=Linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/1rods/) 

## Github Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=1rods&theme=transparent&bg_color=000&border_color=#4747d1&show_icons=true&icon_color=#4747d1&title_color=fff&text_color=FFF&hide_title=true)

[![GitHub Streak](https://streak-stats.demolab.com/?user=1rods&theme=bear&background=000&border=#4747d1&dates=FFF)](https://github.com/1rods)