# Amorais19

Olá! Me chamo Alice e faço técnico em informática no CEFET-MG.

## Conecte-se comigo

[![Gmail](https://img.shields.io/badge/-Gmail-3F8A9B?style=for-the-badge&logo=gmail&logoColor=FFF)](mailto:aliceparttrab@gmail.com)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-3F8A9B?style=for-the-badge&logo=linkedin&logoColor=FFF)](https://www.linkedin.com/in/alice-de-morais-53a226293/)

## Habilidades

Vale lembrar que sou estudante do ensino médio e somente faço técnico integrado, por isso as habilidades abaixo ainda estão sendo aprimoradas. Entretanto, possuo um conhecimento básico de ambas.

![HTML5](https://img.shields.io/badge/HTML5-3F8A9B?style=for-the-badge&logo=html5&logoColor=FFF)
![CSS3](https://img.shields.io/badge/CSS3-3F8A9B?style=for-the-badge&logo=css3&logoColor=FFF)
![C++](https://img.shields.io/badge/C%2B%2B-3F8A9B?style=for-the-badge&logo=c%2B%2B&logoColor=FFF)
![Python](https://img.shields.io/badge/Python-3F8A9B?style=for-the-badge&logo=python&logoColor=FFF)
![JavaScript](https://img.shields.io/badge/JavaScript-3F8A9B?style=for-the-badge&logo=javascript&logoColor=FFF)
![TypeScript](https://img.shields.io/badge/TypeScript-3F8A9B?style=for-the-badge&logo=typescript&logoColor=FFF)
![React](https://img.shields.io/badge/React-3F8A9B?style=for-the-badge&logo=react&logoColor=FFF)

## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Amorais19&theme=transparent&bg_color=3F8A9B&border_color=30A3DC&show_icons=true&icon_color=FFF&title_color=FFF&text_color=FFF&hide=stars)

## Minhas Contribuições

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Amorais19&repo=DIO.me_OpenSource&bg_color=3F8A9B&border_color=FFF&show_icons=true&icon_color=FFF&title_color=FFF&text_color=FFF)](https://github.com/Amorais19/DIO.me_OpenSource)