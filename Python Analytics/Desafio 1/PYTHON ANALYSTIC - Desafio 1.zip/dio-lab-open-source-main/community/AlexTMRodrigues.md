# Alex Teles Mengoni Rodrigues
Olá, meu nome é Alex, tenho 32 anos e estou cursando tecnólogo em ADS.
<p>Desde criança sempre fui fascinado por computadores, desde a montagem das peças até ver tudo funcionando, achava maravilhoso em ver tantas páginas na internet com tanto conteúdo, e hoje finalmente decidi entrar de cabeça a conhecer ainda mais e aprender a desenvolver sites e quem sabe futuramente até softwares.

## Habilidades Básicas em:
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
<br>
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

