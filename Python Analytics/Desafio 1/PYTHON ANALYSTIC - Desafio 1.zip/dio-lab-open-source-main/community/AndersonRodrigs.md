### Olá meu nome é Anderson Rodrigues

## Desenvolvedor Front End

## 🌐 Socials:

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/anderson-rodrigues-s)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/anderson.rodrgs)

## 💻 Tech Stack:

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)

## 📊 GitHub Stats:

<div >
  <a href="https://github.com/AndersonRodrigs">
    
![](https://github-readme-stats.vercel.app/api?username=AndersonRodrigs&theme=react&hide_border=false&include_all_commits=true&count_private=true&bg_color=000)<br/>
![](https://github-readme-streak-stats.herokuapp.com/?user=AndersonRodrigs&theme=react&hide_border=false&background=000)<br/>
![](https://github-readme-stats.vercel.app/api/top-langs/?username=AndersonRodrigs&theme=react&hide_border=false&include_all_commits=true&count_private=true&layout=compact&bg_color=000)
    
</div>
  
---
[![](https://visitcount.itsvg.in/api?id=AndersonRodrigs&icon=1&color=0)](https://visitcount.itsvg.in)
