
# 🚀 Sobre mim

Me chamo Ariana Pinheiro, sou formada em ADS ( Analise e Desenvolvimento de Sistemas ). Atualmente, estou recomeçando e aprendendo muito aqui na Dio, estou deixando a sindrome do falso inspostor que havia em mim apos me formar. A meta é ir em frente independente dos meus erros que cometer durante essa jornada.

### Os sonhos precisam de coragem para serem realizados.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/arianapinheiro-tech/)




## 🧠 Estou aprendendo a programar do zero
⚡️ Fatos engraçados... Sair da faculdade sabendo apenas a teoria como se fosse um enciclopedia 😄


## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=ArianaPinheiro&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Linguagens de Marcação e Estilo
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

## 🛠 Linguagens de Programação
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

## Minhas Contribuições ☺
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=ArianaPinheiro&repo=Dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/ArianaPinheiro/dio-lab-open-source.git)





## Outras Habilidades

- Coursera University of Alberta- Software Architecture
- Hardware Montagem e Manutenção Rede de Computadores.
- Senado Federal- Relações Internacionais
- Gestão de Risco em Ti
- SAP Business One


