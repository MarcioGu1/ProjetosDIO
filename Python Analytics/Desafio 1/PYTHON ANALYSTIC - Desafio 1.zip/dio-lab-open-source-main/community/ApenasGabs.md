
<h2> Hello World!</h2>
<img align="center" alt="GIF" src="https://becode.com.br/wp-content/uploads/2016/10/Por-que-usar-JavaScript.gif" width="400"/>

<h3>  💻 Quem sou eu: </h3>

-   &nbsp; Eu sou o Gabriel Rodrigues mas pode me chamar de Gabs, 
- 🔭 &nbsp; Estou estudando JavaScript e seus Frameworks, principalmente React;
- 🎓 &nbsp; Apaixonado por tecnologia, cursei Eletroeletronica no COTUCA - Colégio Técnico de Campinas da Unicamp;
- 🎓 &nbsp; Formado em Análise e Desenvolvimento de Sistemas - UniMetrocamp;
- 🎓 &nbsp; Especialização Tecnolgias Microsoft - Extecamp Unicamp;
- 🎓 &nbsp; Cursando uma pós-graduação, especialização em projetos de aplicativos móveis multiplataforma - Descomplica Faculdade Digital;
- 💼 &nbsp; Já fui QA por pouco mais de 3 anos e hoje atuo como dev Front-End a cerca de 2 anos, mas estou sempre em busca de novas oportunidades de aprendizado;
- :computer: &nbsp; Gosto de participar de eventos sobre várias tecnologias para fazer network com qualquer dev e entender um pouco mais desse mundo gigante em que estamos conectados;
- :iphone: &nbsp; Minha paixão é criar, gosto de mexer com automação residencial no meu tempo livre, coisas com alexa, google nest e arduino/Raspberry, mas fora da pandemia praticava esportes como skate e parkour;

<h3>⚛️ &nbsp; Competências Técnicas: </h3>

- 💻 &nbsp; HTML | CSS | JavaScript | TypeScript | Python | GoLang   
- 🌐 &nbsp; ReactJs | ReactTs| Next.Js | Styled Components | PWA
- :scroll: &nbsp; NodeJS | Express | Python | Flask | GraphQL
- :art: &nbsp; Visual Studio | Visual Studio code | Figma | Whimsical
- 🔧 &nbsp; Scrum | Kanban | Git | Github | Docker

<br>
<details>
<summary>Quanto tempo codei nesse ano 🤔</summary>
<a align="center" href="https://apenasgabs-info.vercel.app/api/wakatime?username=Apenasgabs"><img align="center" src="https://apenasgabs-info.vercel.app/api/wakatime?username=Apenasgabs&layout=compact&theme=radical&locale=pt-br" />
</a>
</details>
<details>
<summary>Estatísticas do GitHub 🤩</summary>
<a align="center" href="https://apenasgabs-info.vercel.app/api?username=apenasgabs&show=reviews,prs_merged,prs_merged_percentage&show_icons=true&theme=radical"><img height=300 align="center" src="https://apenasgabs-info.vercel.app/api?username=apenasgabs&include_all_commits=true&show=reviews,prs_merged,prs_merged_percentage&show_icons=true&theme=radical&locale=pt-br" />
</a>
</details>
<details>
<summary>Top 6 linguagens mais usadas 😁</summary>
<a align="center" href="https://apenasgabs-info.vercel.app/api/top-langs/?username=apenasgabs&locale=pt-br&hide=c,html,c%2B%2B,processing,makefile,nix,css&layout=pie&theme=radical"><img align="center" height=300  src="https://apenasgabs-info.vercel.app/api/top-langs/?username=apenasgabs&hide=c,html,c%2B%2B,processing,makefile,nix,css&layout=pie&theme=radical&locale=pt-br" alt="Apenasgabs's github stats" />
</a>
</details>
</br>

  
<h2> 🌐 Vamos tomar aquele ☕ e fazer NetWork, contem comigo: </h2>
<p>
&nbsp; <a align="center" href="https://www.linkedin.com/in/Apenasgabs/" target="_blank" rel="noopener noreferrer"><img align="center" src="https://img.icons8.com/plasticine/100/000000/linkedin.png" width="50" /></a>
&nbsp; <a align="center" href="mailto:apenasgabs.dev@gmail.com" target="_blank" rel="noopener noreferrer"><img align="center" src="https://img.icons8.com/plasticine/100/000000/gmail.png"  width="50" /></a>
</p>

