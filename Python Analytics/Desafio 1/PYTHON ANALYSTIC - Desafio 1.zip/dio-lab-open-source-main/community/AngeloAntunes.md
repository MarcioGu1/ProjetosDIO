# Angelo Antunes

Olá! Meu nome é Angelo e sou um apaixonado __Desenvolvedor de Software__ com uma trajetória de __2 anos de experiência__, focado em aprimorar a experiência do usuário por meio de interfaces de alta qualidade. Com conhecimento em Front-End e suas linguagens, além de ferramentas de Designer para criar interfaces visualmente atraentes e funcionais.

Para saber __mais sobre mim__, minhas __habilidades__ e trocarmos __experiências__, conecte-se comigo clicando nas minhas redes que se encontram na seção abaixo .

## Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/angeloantunes/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AngeloAntunes)
