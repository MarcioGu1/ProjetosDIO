### Olá Eu sou Alexandre Araujo da Silva, tenho 41 anos e estou em transição de carreira buscando minha primeira vaga no mercado de tecnologia ✋

## 👷 Vencendo grandes desafios e superando grande obstáculos! 👩‍🔧
<hr>

[![Linkedin](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alexandre-araujo-da-silva-0970191aa)
[![youtube](https://img.shields.io/badge/YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://www.youtube.com/@alexandresilva766/)
[![Twitch](https://img.shields.io/badge/Twitch-9146FF?style=for-the-badge&logo=twitch&logoColor=white)](https://www.instagram.com)
[![Instagram](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com)

![AlexDeveloperOne GitHub stats](https://github-readme-stats.vercel.app/api?username=AlexDeveloperOne&show_icons=true&theme=dracula)

[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=alexdeveloperone&hide=javascript,html)]

<!---
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=alexdeveloperone&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

--->
## Tecnologias que eu uso no meu dia

<div style="display: inline_block"><br/>
    <img align="center" alt="html5"src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white"/>
    <img align="center" alt="css"src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white"/>
    <img align="center" alt="javascript" src="https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E"/>
    <img align="center" alt="sass" src="https://img.shields.io/badge/Sass-CC6699?style=for-the-badge&logo=sass&logoColor=white"/>
    <img align="center" alt="node.js"src="https://img.shields.io/badge/Node.js-43853D?style=for-the-badge&logo=node.js&logoColor=white"/>
    <img align="center" alt="java"src="https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=spring&logoColor=white"/>
    <img align="center" alt="angular"src="https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white"/>
    <img align="center" alt="c"src="https://img.shields.io/badge/C-00599C?style=for-the-badge&logo=c&logoColor=white"/>
    <img align="center" alt="c++"src="https://img.shields.io/badge/C%2B%2B-00599C?style=for-the-badge&logo=c%2B%2B&logoColor=white"/>
    <img align="center" alt="c++"src="https://img.shields.io/badge/REST-API-green?style=for-the-badge&logo=fastapi&logoColor=white"/>
    

</div>
<hr>

[![GitHub Streak](https://streak-stats.demolab.com?user=AlexDeveloperOne&hide_border=true&locale=pt_BR&background=45%2CEB5454%2C802E2E)](https://git.io/streak-stats)