# André L. Pavan  

Sou entusiasta pela tecnologia com o objetivo de entrar definitivamente na área. Resido em Lages, SC - Brasil.</h3>

Atualmente trabalho como administrador de empresa, onde uma das atribuições está ligado a tecnologia.

Estou buscando ajuda via os cursos da DIO o desenvolvido pessoal, conhecendo as linguagens mais atuais para definir qual caminho seguir. Tenho conhecimento básico em python e sql.

### Conecte-se comigo

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/Alpavan)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:alpavan@hotmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/Andrelpavan)

### Habilidades

[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)

### GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=alpavan&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)