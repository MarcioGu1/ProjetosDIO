# Arrigo Valêncio

Eu sou o Arrigo e estou no bootcamp cibersegurança pela curiosidade e interesse em conhecer e aprofundar no tema.

## Conecte-se comigo através do: 
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/arrigo-valêncio-4b5678217/)

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/ArrigoValencio)

## Habilidades
![R](https://img.shields.io/badge/R-276DC3?style=for-the-badge&logo=r&logoColor=white)

![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)

## Linguagens mais usadas e repositórios no GitHub

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=ArrigoValencio&bg_color=000&border_color=30A3DC&title_color=E94D5F&hide_title=true&text_color=FFF)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=ArrigoValencio&repo=estudos_series_temporais_R&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/ArrigoValencio/estudos_series_temporais_R)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=ArrigoValencio&repo=dados_em_R&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/ArrigoValencio/dados_em_R)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=ArrigoValencio&repo=estudos_livro_entendendo_algoritmos&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/ArrigoValencio/estudos_livro_entendendo_algoritmos)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=ArrigoValencio&repo=projeto_agenda&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/ArrigoValencio/projeto_agenda)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=ArrigoValencio&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/ArrigoValencio/dio-lab-open-source)

## Leia meus trabalhos acadêmicos em economia:

    Dissertação (mestrado): https://poseconomia.ufv.br/wp-content/uploads/2012/02/Dissertacao-Arrigo.pdf

    Tese (doutorado): http://hdl.handle.net/1843/39003