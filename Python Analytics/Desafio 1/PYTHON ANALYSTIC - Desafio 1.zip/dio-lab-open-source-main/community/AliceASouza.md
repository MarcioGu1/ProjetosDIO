# Alice Souza 💜
Olá, Me chamo Alice, atuando como professora de informática de PEB I (Para crianças de 1º a 5º Ano), buscando uma transição de carreira para a área da programação como desenvolvedora Full Stack.
## 😄 Conecte-se comigo 
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alicealvesdesouza/) 
[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AliceASouza)
[![Perfil DIO](https://img.shields.io/badge/-Perfil%20DIO-0A66C2?style=for-the-badge)](https://web.dio.me/users/alicinha_carter)
## 💡 Habilidades
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![Windows](https://img.shields.io/badge/Windows-000?style=for-the-badge&logo=windows&logoColor=2CA5E0)
![Ubuntu](https://img.shields.io/badge/Ubuntu-35495E?style=for-the-badge&logo=ubuntu&logoColor=2CA5E0)
![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)
![Vscode](https://img.shields.io/badge/Vscode-007ACC?style=for-the-badge&logo=visual-studio-code&logoColor=white)
## 📌 GitHub Status
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AliceASouza&theme=transparent&bg_color=000&border_color=9400D3&show_icons=true&icon_color=9400D3&title_color=9400D3&text_color=fff)