
# **André Lucho**

**Olá, seja Bem vindo!**

### Farmacêutico formado desde 2009, apaixonado pela área de TI! Desde 2022, dedicado exclusivamente a área de Desenvolvimento de software 

<br>

**Hi, there! Be Welcome!**

### I'm a Pharmacist gradueted since 2009 and passionate about IT! Since 2022, dedicated exclusively to the Software Development area

<br>

## **Vamos nos Conectar ??** / **Let's get connected ??**

[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://github.com/Andre-Lucho)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0A66C2)](https://www.linkedin.com/in/SEUUSERNAME/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/andre_tlucho/)
[![Gmail](https://img.shields.io/badge/-Gmail-000?style=for-the-badge&logo=gmail&logoColor=gmail)](mailto:andretlucho@gmail.com)
[![Perfil DIO](https://img.shields.io/badge/-DIO%20Profile-000?style=for-the-badge&logo=d&logoColor=0E76A8)](https://web.dio.me/users/andretlucho)

<br>

## **Habilidades** / **Skills**

|**Hard Skills developed so far**| **Hard Skills in development**|
|---------------|------------|
|![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)|![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)|![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![GIT](https://img.shields.io/badge/git-000?style=for-the-badge&logo=git)|![Flutter](https://img.shields.io/badge/flutter-000?style=for-the-badge&logo=flutter&logoColor=02569B)
![VSCODE](https://img.shields.io/badge/vscode-000?style=for-the-badge&logo=visualstudiocode&logoColor=007ACC)|![Dart](https://img.shields.io/badge/dart-000?style=for-the-badge&logo=dart&logoColor=0175C2)

<br>

## **GitHub Status**

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=andre-lucho&&theme=radical&include_all_commits=true&show_icons=true)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=SEUUSERNAME&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

<br>


## **Principais Projetos** / **Main Contributions** 

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=andre-lucho&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/andre-lucho/dio-lab-open-source)