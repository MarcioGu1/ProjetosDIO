# Álvaro #

## Olá! sou dev front-end iniciante, no momento estou cursando Ánalise e desenvolvimento de sistemas ##

# Habilidades #
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![GIT](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git)
![GITHUB](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=github)



