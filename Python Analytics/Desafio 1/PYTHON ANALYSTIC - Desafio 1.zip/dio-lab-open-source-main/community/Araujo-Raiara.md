# Hey there i'm Raiara

### Conecte-se comigo:

![playstation](https://img.shields.io/badge/PlayStation-003791?style=for-the-badge&logo=playstation&logoColor=white) 
[![Discord](https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white)](https://www.discord.com/in/raiarauju/)
[![Discord](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/raiara-a-6541a3193/)


### Tools and languages

![Azure](https://img.shields.io/badge/microsoft%20azure-0089D6?style=for-the-badge&logo=microsoft-azure&logoColor=white)
![Firebase](https://img.shields.io/badge/Firebase-039BE5?style=for-the-badge&logo=Firebase&logoColor=white)
![Android Studio](https://img.shields.io/badge/Android%20Studio-3DDC84.svg?style=for-the-badge&logo=android-studio&logoColor=white)
![Visual Studio](https://img.shields.io/badge/Visual%20Studio-5C2D91.svg?style=for-the-badge&logo=visual-studio&logoColor=white)
![Eclipse](https://img.shields.io/badge/Eclipse-FE7A16.svg?style=for-the-badge&logo=Eclipse&logoColor=white)
![MicrosoftSQLServer](https://img.shields.io/badge/Microsoft%20SQL%20Server-CC2927?style=for-the-badge&logo=microsoft%20sql%20server&logoColor=white)
![Kotlin](https://img.shields.io/badge/kotlin-%237F52FF.svg?style=for-the-badge&logo=kotlin&logoColor=white)
![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white)
![Figma](https://img.shields.io/badge/figma-%23F24E1E.svg?style=for-the-badge&logo=figma&logoColor=white)
![C#](https://img.shields.io/badge/c%23-%23239120.svg?style=for-the-badge&logo=c-sharp&logoColor=white)
![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white)
![Git](https://img.shields.io/badge/git-%23F05033.svg?style=for-the-badge&logo=git&logoColor=white)

## Um pouco sobre mim:

Eu tenho 4 gatos

amo jogar video game 

gosto muito de ler noticias e artigos relacionados ao espaço.

amo dar uma de chef de cozinha haha, modestia parte eu cozinho bem. Gosto de comidas de diferentes culturas, mas a meu tipo de comida favorita é comida indiana.

Sou viciada em café, que dev que não é não é mesmo?

amo animes, inclusive mais antigos. No momento eu finalizei o anime hajime no Ippo, e estou vendo os filmes.

Analista de software apaixonada por tecnologia.

Meu primeiro contato com programação foi lá nos meus 16 anos quando entrei para a Etec, no inicio eu fiquei com medo e achava que não era pra mim, porque quando eu passei na prova, por o nome do curso ser Tecnico de Informatica eu imaginava que o curso estaria mais relacionado a hardware e fui supreendida por a grade do curso que era tudo relacionado a desenolvimento de software. Decidi dar uma chance e me apaixonei principalmente por c#.

Por um bom tempo eu levei programação como um hobby, até pedir demissão do meu emprego onde eu via que estava fazendo algo que não me trazia felicidade e voltei a estudar programação, agora estou me dedicando ao desenvolvimento mobile android que é uma stack que me entrou no meu coração (uma coisa engraçada relacionado a essa última frase é que quando tive materia de desenvovimento android na etec era a materia que eu detestava ç-ç)

Acho que por enquanto é só isso * - *
![Meme](https://media2.giphy.com/media/fPOm3oqOWNFOMlLH1I/giphy.gif?cid=ecf05e470pr0iqgj93ilvklkdyxtzzruuki0axxw4wqw2tbo&ep=v1_gifs_related&rid=giphy.gif&ct=g)
