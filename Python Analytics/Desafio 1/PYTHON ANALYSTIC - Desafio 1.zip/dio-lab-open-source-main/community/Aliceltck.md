
# Conecte-se Comigo !


Olá eu sou Alice e estou querendo conhecer um pouquinho desse mundo da programação!!


## 🚀 Sobre mim
Trabalho com moda...Estou pensando em imigrar de carreira...


[![WhatsApp](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/31975319669
)
[![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red)](mailto:aliceltck@gmail.com)




## Atualmente
👩‍💻 Trabalho atualmente com moda

🧠 Estou aprendendo Git e GitHub

👯‍♀️ Procuro colaborar em projetos






![GitHub Stats](https://github-readme-stats.vercel.app/api?username=SEUUSERNAME&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)



