br>


# 🔎 SOBRE MIM

<br>

## 🖊 Descrição
Sou estudante do ensino médio/técnico em informática para internet, estou no último ano da curso e pretendo continuar na área de informática. Além disso sou estagiário em um banco da minha cidade.

___
<BR>

## 🙋‍♂️Experiência no mercado de trabalho
Comecei a trabahar as 15 anos como menor aprendiz bancário, trabalhei por 2 anos como aprendiz depois ingressei em um banco como estagiário, emprego que estou atualemente.

<BR>

## ☎ Contato
* [**Linkedin**](www.linkedin.com/in/andré-luiz-siqueira12)
* **Email:** dresiqueira12@gmail.com
* [**Perfil DIO**](https://github.com/Andre-L12)

----------------
Experiências e conhecimentos
------

![GitHub](https://img.shields.io/badge/GitHub-1?style=for-the-badge&logo=github&logoColor=white)
![Bootstrap](https://img.shields.io/badge/-boostrap-C0C0C0?style=for-the-badge&logo=bootstrap&labelColor=#C0C0C0)
![MySQL](https://img.shields.io/badge/MySQL-191970?style=for-the-badge&logo=mysql&logoColor=white)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-F5FFFA?style=for-the-badge&logo=postgresql)
![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)
![Vscode](https://img.shields.io/badge/Vscode-007ACC?style=for-the-badge&logo=visual-studio-code&logoColor=white)
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white)
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
![Ubuntu](https://img.shields.io/badge/Ubuntu-35495E?style=for-the-badge&logo=ubuntu&logoColor=2CA5E0)
![Windows](https://img.shields.io/badge/Windows-000?style=for-the-badge&logo=windows&logoColor=2CA5E0)
