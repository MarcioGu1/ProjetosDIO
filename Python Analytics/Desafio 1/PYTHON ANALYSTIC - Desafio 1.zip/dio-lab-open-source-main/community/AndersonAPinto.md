

### Muito prazer, Anderson aqui! ✌️

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/andersonapinto/)
[![Instagram](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/andersonaugusto.pinto/)
[![Whatsapp](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://api.whatsapp.com/send?phone=5551997802755&text=Ol%C3%A1%20muito%20prazer,%20tudo%20bem?%0AObrigado%20por%20entrar%20em%20contato.%0AEstou%20pronto%20para%20solucionar%20o%20seu%20problema?)
[![Gmail](	https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](andersonaugustopinto@gmail.com)
[![WebSite](https://img.shields.io/badge/website-000000?style=for-the-badge&logo=About.me&logoColor=white)](andersonpinto.com.br)

![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=AndersonAPinto&show_icons=true&theme=merko)


## Tecnologias utilizadas recentemente...

<div style="display:inline_block"><br/>
    <img align="center" alt="JavaScript" src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black"/>
    <img align="center" alt="Node.Js" src="https://img.shields.io/badge/Node.js-43853D?style=for-the-badge&logo=node.js&logoColor=white"/>
    <img align="center" alt="Html5" src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white"/>
    <img align="center" alt="CSS" src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white"/>
    <img align="center" alt="Python" src="https://img.shields.io/badge/Python-14354C?style=for-the-badge&logo=python&logoColor=white"/>
    <img align="center" alt="React" src="https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB"/>
</div><br/>

Entusiasta de novas tecnologias, buscando e criando projetos inéditos afim de transformar e melhorar a minha e outras vidas.

#### Últimos projetos
- [Web Site: Teste de Inglês](https://testedeingles.app.br)
- [Custo de Recarga - Carros Elétricos](https://andersonapinto.github.io/ConsumoCarroEletrico/)
- [Site ecommerce: GADJ Ferramentas](https://gadjferramentas.com.br)



