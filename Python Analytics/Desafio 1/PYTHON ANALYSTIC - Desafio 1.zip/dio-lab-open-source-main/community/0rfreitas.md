# 👋 Olá, pode de chamar de Rick!
Atualmente sou um estudante de Ciência da Computação apaixonado por desenvolvimento web.

##
### 📊 Estatísticas no GitHub:
<a href="https://github.com/0rfreitas">
  <img height=200 align="center" src="https://github-readme-stats.vercel.app/api?username=0rfreitas&locale=pt-br&show_icons=true&include_all_commits=true&count_private=true&\&rank_icon=github" />
</a>

##
### 👨‍💻 Principais Tecnologias e Ferramentas 🛠

<div style="display: inline_block"><br/>
<img aLign="center" alt="HTML 5" src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white" />
<img aLign="center" alt="CSS" src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white" />
<img aLign="center" alt="JavaScript" src="https://img.shields.io/badge/JavaScript-323330?style=for-the-badge&logo=javascript&logoColor=F7DF1E" />
<img aLign="center" alt="Angular" src="https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white" />
<img aLign="center" alt="Java" src="https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white" />
<img aLign="center" alt="Spring" src="https://img.shields.io/badge/Spring-6DB33F?style=for-the-badge&logo=spring&logoColor=white">
<img aLign="center" alt="​SQL SERVER" src="https://img.shields.io/static/v1?label=%E2%80%8B&message=SQL+SERVER&color=CC2927&style=for-the-badge&logo=microsoftsqlserver">
<img aLign="center" alt="AWS" src="https://img.shields.io/badge/Amazon_AWS-FF9900?style=for-the-badge&logo=amazonaws&logoColor=white" />
<img aLign="center" alt="Jira" src="https://img.shields.io/badge/Jira-0052CC?style=for-the-badge&logo=Jira&logoColor=white" />

</div>

##
### 🤓 Estudando atualmente:

<div style="display: inline_block"><br/>
<img aLign="center" alt="TypeScript" src="https://img.shields.io/badge/typescript-%23007ACC.svg?style=for-the-badge&logo=typescript&logoColor=white" />
<img aLign="center" alt="Angular" src="https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white" />
<img aLign="center" src="https://img.shields.io/badge/Ingl%C3%AAs-2ea44f?style=for-the-badge" alt="Inglês"></a>
</div>

##
### 📲 Você pode me encontrar em:

[![LinkedIn](https://img.shields.io/badge/linkedin-%230077B5.svg?style=for-the-badge&logo=linkedin&logoColor=white)](https://br.linkedin.com/in/rfreitas0)
