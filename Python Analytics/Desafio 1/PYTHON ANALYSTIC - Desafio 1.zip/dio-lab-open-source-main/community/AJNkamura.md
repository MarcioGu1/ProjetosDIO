## Olá, sou Amanda! 👩🏻‍💻   
Me chamo Amanda Jury Nakamura e sou veterinária e estudante de Sistemas de Informação pela UTFPR. 

 🔹 Tenho grande interesse na área de desenvolvimento, análise de dados, estatística e Business Intelligence. 📊

🔹 Gosto de programar, mas também tenho apreço pela gestão. 🖥️+🗂️

🔹 Estou construindo meu caminho na tecnologia através da criatividade, comunicação, pró-atividade e muita vontade de aprender! 💡🧠


## ⚒️ Habilidades 
![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c) 
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AJNkamura&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)




## 📚 Idiomas
- Inglês avançado (Cambridge English Level 2 Certificate ESOL International (Advanced)
- Japonês intermediário
- Espanhol básico

## 📲 Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/ajnkamura/) 
[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://www.discord.com/in/aj_nkamura/)
