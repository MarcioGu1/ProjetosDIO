# Adriana Pugarito 

# Vamos conectar ? Me siga ou se preferir podemos bater um papo! 

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/adriana-pugarito/) [![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AdrianaPugarito)   [![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red)](mailto:adrianapugarito46@gmail.com)

# Algumas linguagens de programação que ja usei : 

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AdrianaPugarito&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

[![GitHub Streak](https://streak-stats.demolab.com/?user=AdrianaPugarito&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)