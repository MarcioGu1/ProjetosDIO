# Richard Amaral Fernandes

## Me chamo Richard, estou começando na área de Ciências de Dados, já que vejo um grande potencial nesta área.

# Conecte-se Comigo:

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/richard-amaral-fernandes-75209228a/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/ricky.a.fernandes/)

# Habilidades:

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)