<h1 align="center">Hello There👋, I'm Adiel Sobral Melo</h1>
<h3 align="center">Looking for to be a good Web Backend Developer</h3>

##

- 📚 Student of Systems for Internet at **Instituto Federal da Paraíba (IFPB)**



## - 🌱 I’m currently learning:

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![MySQL](https://img.shields.io/badge/MySQL-000?style=for-the-badge&logo=mysql)

##   🚀  Some Tools and Technologies that I use:

![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git)
![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github)
![VSCode](https://img.shields.io/badge/VSCode-000?style=for-the-badge&logo=visualstudiocode)
![Linux](https://img.shields.io/badge/Linux-000?style=for-the-badge&logo=linux)
![Windows](https://img.shields.io/badge/Windows-000?style=for-the-badge&logo=windows)
!

## - 📫 How to reach me:

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/adiel-melo-073009273/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram&logoColor=8a3ab9)](https://www.instagram.com/y2k.adiel/)
[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord&logoColor=7289DA)](https://discord.com/users/852597549171867648)

## - 📊 Some Stats:

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AdielSM&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

[![GitHub Streak](https://streak-stats.demolab.com/?user=AdielSM&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)

![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=AdielSM&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)


