[![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=87CEFA&size=35&center=true&vCenter=true&width=1000&lines=Alan+David;Desenvolvedor+de+Software;Bem+vindo+ao+meu+perfil+do+GitHub+:%29)](https://git.io/typing-svg)

Sempre tive uma conexão com tecnologia por meio de video games, e foi só depois de um tempo que resolvi mergulhar nesse mundo como programador e descobri que a programação sempre foi minha paixão.

## Habilidades
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)
![.NET](https://img.shields.io/badge/.Net-000?style=for-the-badge&logo=.net&logoColor=823085)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git)
![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)

## Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/alan_david_pereira/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=0E76A8)](https://github.com/AlanMorfeu)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alan-david-pereira-002556205/)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AlanMorfeu&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AlanMorfeu&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)


