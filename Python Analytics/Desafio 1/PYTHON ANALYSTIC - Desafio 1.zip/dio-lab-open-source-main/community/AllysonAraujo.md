## Allyson Araujo
Apaixonado por tecnologia, aventuras, e café.


## 🚀 Sobre mim
Possuo conhecimentos de Java, Dynamics 365 - Sales, C#.

## 🔗 Conecte-se comigo
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AllysonAraujo)
[![MeuPerfilnaDIO](https://img.shields.io/badge/Meu_perfil_na_dio-000?style=for-the-badge&logo=ko-fi&logoColor=white)](https://www.dio.me/users/allyson_araujo)
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/allysonaraujo)
[![instagram](https://img.shields.io/badge/instagram-1DA1F2?style=for-the-badge&logo=instagram&logoColor=white)](https://instagram.com/allyson_arauj0)


## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AllysonAraujo&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF&hide_title=true)
## Meus Principais Desafios de Projeto DIO

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=allysonaraujo&repo=Trilha-net-fundamentos-desafio&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/ALLYSONARAUJO/trilha-net-fundamentos-desafio&hide_title=true)
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=allysonaraujo&repo=trilha-net-poo-desafio&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/ALLYSONARAUJO/trilha-net-poo-desafio&hide_title=true) 

## Habilidades
![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white)
![C#](https://img.shields.io/badge/C%23-239120?style=for-the-badge&logo=c-sharp&logoColor=white)
![Kotlin](https://img.shields.io/badge/Kotlin-0095D5?&style=for-the-badge&logo=kotlin&logoColor=white)
[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/allysonaraujo)
![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)
![Vscode](https://img.shields.io/badge/Vscode-007ACC?style=for-the-badge&logo=visual-studio-code&logoColor=white)
