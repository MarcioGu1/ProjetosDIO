# Olá! Me chamo Ariston, mas pode me chamar de **Aristec1** 💻⚙🔧
### Sou graduando na Eng.Controle e Automação pelo IFPA - Campus Belém, atualmente estou buscando novas inovações e descobertas no mundo da programação para a minha área, amo fazer projetos, fazer engenharia reversa em eletrônicos e nas horas vagas adoro jogar um Valorant 😜.

## Conecte-se Comigo
[![LinkedIn](https://img.shields.io/badge/instagram-FFF?style=for-the-badge&logo=instagram)](https://www.instagram.com/akanato__/)
[![Discord](https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white)](https://https://discord.com/channels/@akanato/)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/ariston-monteiro-210267200/)

[![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red)](mailto:mariston748@gmail.com)

## 📖Habilidades Adquiridas:
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
![Windows](https://img.shields.io/badge/Windows-000?style=for-the-badge&logo=windows&logoColor=2CA5E0)

![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)
![Vscode](https://img.shields.io/badge/Vscode-007ACC?style=for-the-badge&logo=visual-studio-code&logoColor=white)

## 🤓 Ainda em Estudos:
![C#](https://img.shields.io/badge/C%23-239120?style=for-the-badge&logo=c-sharp&logoColor=white)
![Ubuntu](https://img.shields.io/badge/Ubuntu-35495E?style=for-the-badge&logo=ubuntu&logoColor=2CA5E0)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)

![C++](https://img.shields.io/badge/C%2B%2B-00599C?style=for-the-badge&logo=c%2B%2B&logoColor=white)
![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)

## Estatísticas atuais no GitHub:
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Aristec1&layout=compact&bg_color=000&border_color=f0da22&title_color=f0da22&text_color=8d23f7)
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Aristec1&theme=transparent&bg_color=000&border_color=f0da22&show_icons=true&icon_color=32f72f&title_color=f0da22&text_color=8d23f7)
