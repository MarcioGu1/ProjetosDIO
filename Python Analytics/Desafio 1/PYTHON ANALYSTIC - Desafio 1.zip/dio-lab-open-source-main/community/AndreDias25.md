
# André Henrique

- Desenvolvedor Front-end
- 2 anos de experiência

## Habilidades

- Angular
- TypeScript
- SalesForce Commerce Cloud

🍀“Se um homem não sabe para qual porto navega, nenhum vento lhe é favorável.” – Sêneca

