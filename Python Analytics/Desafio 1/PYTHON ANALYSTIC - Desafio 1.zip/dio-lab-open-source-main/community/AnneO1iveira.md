# AnneO1iveira
Oi, eu sou a Annelise, mas podem me chamar de Anne. Trabalho com javascript em ServiceNow, mas atualmente estou buscando ampliar meus horizontes aprendendo novas linguagens. Sou nova no mundo do github, mas sintam-se a vontade para se conectarem comigo no linkedin.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-FF5DC3?style=for-the-badge&logo=linkedin&logoColor=)](https://www.linkedin.com/in/anneliseoliveira/)

## Habilidades
![JavaScript](https://img.shields.io/badge/JavaScript-FF5DC3?style=for-the-badge&logo=javascript) ![Java](https://img.shields.io/badge/Java-FF5DC3?style=for-the-badge&logo=java) ![Sass](https://img.shields.io/badge/Sass-FF5DC3?style=for-the-badge&logo=sass)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AnneO1iveira&theme=transparent&bg_color=FF5DC3&border_color=000000&show_icons=true&icon_color=000000&title_color=000000&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AnneO1iveira&layout=compact&bg_color=FF5DC3&border_color=000000&title_color=000000&text_color=FFF)
