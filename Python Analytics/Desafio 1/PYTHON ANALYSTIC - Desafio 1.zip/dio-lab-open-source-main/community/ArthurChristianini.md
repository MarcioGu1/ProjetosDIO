# Arthur Christianini

## Meios de Contato
[![LinkedIn](https://img.shields.io/badge/LinkedIn-930086?style=for-the-badge&logo=linkedin&logoColor=FFF)](https://www.linkedin.com/in/arthur-christianini-6b4ba9213/)

[![Instagram](https://img.shields.io/badge/Instagram-930086?style=for-the-badge&logo=instagram&logoColor=FFF)](https://www.instagram.com/arthukk_/)

## Habilidades
![Markdown](https://img.shields.io/badge/Markdown-bbb?style=for-the-badge&logo=markdown&logoColor=000)
![HTML5](https://img.shields.io/badge/HTML5-ff9500?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-6a84e1?style=for-the-badge&logo=css3&logoColor=264CE4)

![JavaScript](https://img.shields.io/badge/JavaScript-ffff9e?style=for-the-badge&logo=javascript)
[![GitHub](https://img.shields.io/badge/GitHub-8fddff?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)
[![Git](https://img.shields.io/badge/Git-cd435b?style=for-the-badge&logo=git&logoColor=ff8b77)](https://git-scm.com/doc) 

## GitHub Stats

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=ArthurChristianini&bg_color=000&border_color=930086&title_color=930086&text_color=FFF)

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=ArthurChristianini&theme=transparent&bg_color=000&border_color=930086&show_icons=true&icon_color=30A3DC&title_color=930086&text_color=FFF)


## Minhas Contribuições e Portfólio

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=ArthurChristianini&repo=Portfolio&bg_color=000&border_color=930086&show_icons=true&icon_color=930086&title_color=930086&text_color=FFF)](https://github.com/ArthurChristianini/Portfolio)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=ArthurChristianini&repo=dio-lab-open-source&bg_color=000&border_color=930086&show_icons=true&icon_color=930086&title_color=930086&text_color=FFF)](https://github.com/ArthurChristianini/dio-lab-open-source)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=ArthurChristianini&repo=Sistema-de-Avaliacao&bg_color=000&border_color=930086&show_icons=true&icon_color=930086&title_color=930086&text_color=FFF)](https://github.com/ArthurChristianini/Sistema-de-Avaliacao)