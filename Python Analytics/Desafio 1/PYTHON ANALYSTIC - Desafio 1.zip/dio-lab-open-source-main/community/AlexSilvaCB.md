<h1>Alex Silva</h1>

<h3>“Não é a linguagem de programação que define o programador, mas sim sua lógica.”</h3>
<h4 align="right">David Ribeiro Guilherme</h4>

<div align="center">
 <img width="400px" src="alex silva.gif" />
</div>

<h1> Linguagens e Frameworks </h1>

<div>
  <h2> Marcação </h2>
  <img alt="Static Badge" src="https://img.shields.io/badge/HTML5-0?style=social&logo=html5"> .
  <img alt="Static Badge" src="https://img.shields.io/badge/CSS3-0?style=social&logo=css3"> .
  <img alt="Static Badge" src="https://img.shields.io/badge/SASS-0?style=social&logo=sass">

 <div align="center">
   <h2> Programação </h2>
   <img alt="Static Badge" src="https://img.shields.io/badge/JAVASCRIPT-0?style=social&logo=JavaScript&logoColor=yellow"> .
   <img alt="Static Badge" src="https://img.shields.io/badge/TYPESCRIPT-0?style=social&logo=TypeScript&logoColor=blue"> .
   <img alt="Static Badge" src="https://img.shields.io/badge/JAVA-0?style=social&logo=coffeescript">
 </div>

 <div  align="right">
   <h2> Frameworks </h2>
   <img alt="Static Badge" src="https://img.shields.io/badge/ANGULAR-0?style=social&logo=Angular"> . 
   <img alt="Static Badge" src="https://img.shields.io/badge/SPRING-0?style=social&logo=Spring"> .
   <img alt="Static Badge" src="https://img.shields.io/badge/SPRINGBOOT-0?style=social&logo=SpringBoot">
  </div>

  <h2> Ferramentas </h2>
  <img alt="Static Badge" src="https://img.shields.io/badge/GIT-0?style=social&logo=git"> .
  <img alt="Static Badge" src="https://img.shields.io/badge/GITHUB-0?style=social&logo=github"> .
  <img alt="Static Badge" src="https://img.shields.io/badge/POSTMAN-0?style=social&logo=postman">
</div>

<div align="center">
 <h1> Detalhes </h1>
<img   height="200em" src="https://github-readme-stats.vercel.app/api?username=AlexSilvaCB&count_private=true&show_icons=true&theme=dracula"/>

<img height="200em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=AlexSilvaCB&layout=compact&theme=dracula"/>
<img src="https://github.com/LuigiGF/LuigiGF/blob/output/github-contribution-grid-snake.svg">
</div>
