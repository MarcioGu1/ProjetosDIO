# **Antonio Macena**

## *About*

Estou numa jornada para ingressar profissionalmente na área de TI, pois o que antes era apenas um hobby tornou-se um objetivo de vida. Sou atencioso e me adapto rapidamente a mudanças quando necessário. Tenho certa proficiência em inglês e programação, especialmente em "C, Java e Python", com grande interesse em Ciência de Dados e Cloud Computing.


[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=FFEB3B)](https://www.linkedin.com/in/antonio-macena/)




