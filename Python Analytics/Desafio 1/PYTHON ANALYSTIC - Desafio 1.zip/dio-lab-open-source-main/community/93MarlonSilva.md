<style type="text/css">
  body {
    background-color: #000000;
  }
</style>
<div>
  <div style="background-color: #171919" >
    <h2 style="color: #bdbdbd;">
     &nbsp &nbsp &nbsp  Marlon 
    </h2>
  </div>
</div>
  <h1 style="color: #ffffff">
    &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Marlon Silva
  </h1>
  <h4 style="color: #ffffff"> &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp   &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Flutter developer</h4>
<div align="center"> <a href="https://imgbox.com/A8HDaCAb" target="_blank"><img src="https://thumbs2.imgbox.com/96/f3/A8HDaCAb_t.jpeg" alt="image host"/></a></div>
<div style="background-color: rgb(0, 0, 0); " >
<table style="color:#bdbdbd"  >
  <thead>
    <tr align="left"  >
      <th style="font-size:28">Hard Skills</th>
    </tr>
    </br>
  </thead>
  <tbody align="left">
    <tr>
      <td>Flutter</td>
      <td align="center">
        <a href="">
          <img align="center" alt="Marlon-Flutter" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/flutter/flutter-original.svg">
        </a>
      </td>
    </tr>
    <tr>
      <td>JavaScript</td>
      <td align="center">
        <a href="">
           <img align="center" alt="Marlon-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
        </a>
      </td>
    </tr>
     <tr>
      <td>ReactJs</td>
      <td align="center">
        <a href="">
           <img align="center" alt="Marlon-React" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/react/react-original.svg">
        </a>
      </td>
    </tr>
     <tr>
      <td>Html</td>
      <td align="center">
        <a href="">
          <img align="center" alt="Marlon-HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
        </a>
      </td>
    </tr>
       <tr>
      <td>NodeJs</td>
      <td align="center">
        <a href="">
           <img align="center" alt="Marlon-Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/nodejs/nodejs-plain.svg">
        </a>
      </td>
       <tr>
      <td>Css</td>
      <td align="center">
        <a href="">
           <img align="center" alt="Marlon-CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
        </a>
      </td>
    </tr>
  </tbody>
</table>
</div>
<div align="center"> 
  <a href="https://www.instagram.com/93marlon_silva/" target="_blank"><img src="https://img.shields.io/badge/-Instagram-D2691E?style=for-the-badge&logo=instagram&logoColor=4B0082" target="_blank"></a>
  <a href = "mailto:marlon.m_silva@outlook.com"><img src="https://img.shields.io/badge/-Outlook-1E90FF?style=for-the-badge&logo=Gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/in/marlon-silva-910b1783/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-000fFF?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
 
 
</div>
 <footer style="background-color: #171919" >
  <p align="center" style="color:white">@2023 Marlon Silva</p>
</footer> 