
---

[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=14&pause=1000&color=AA42F7&width=435&lines=Ola+DEV!+Seja+bem-vindo+ao+meu+perfil+GitHub!;Prazer%2C+meu+nome+%C3%A9+Leonardo+Sousa.)](https://git.io/typing-svg)

# Quem sou eu?
Me chamo Leonardo Sousa, tenho 19 anos de idade. Tenho uma conexão com a tecnologia muito forte desde os 9 anos de idade e por via dos games, me despertou o interesse e o amor pela programação. Estou iniciando minha carreira agora, visando o meio profissional, sempre buscando evolução, apreendizado e novos desafios. Puxando um pouco para o pessoal, assim como a tecnologia, sou apaixonado por musica e por dança desde pequeno. Meu sonho é consolidar uma carreira de conquistas e evolução, fazendo com que as pessoas em minha volta evolua proporcionalmente, seja familia ou amigos. 

### Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/contato_sousa18/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=gmail&logoColor=AA42F7)](mailto:contato.sousa18@gmail.com)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=AA42F7)](https://www.linkedin.com/in/leonardo-sousa-dias-271b75220/)


### Habilidades
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=AA42F7)](https://git-scm.com/doc) 
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=AA42F7)](https://docs.github.com/)
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=23LSDev&theme=transparent&bg_color=000&border_color=AA42F7&show_icons=true&icon_color=AA42F7&title_color=AA42F7&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=23LSDev&layout=compact&bg_color=000&border_color=AA42F7&title_color=AA42F7&text_color=FFF)


---
