
# Adriano de Souza

## Git Status
[![GitHub Streak](https://streak-stats.demolab.com/?user=SEUUSERNAME&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)


[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/adriano-bezerra-tecnico-eletrotecnica-eletroeletronica/)


## Habilidades

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)


![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)


## Sobre mim

|Técnico em Eletrotécnica | Eletroeletrônica | CRMDA + Smart Meter | Cursando Análise e Desenvolvimento de Sistemas|

## RESUMO: 

Atualmente cursando o 3° semestre de Análise e Desenvolvimento de Sistemas na FATEC,  formado como Técnico de Eletrotécnica e Eletroeletrônica pelo Centro Estadual Educacional Tecnológica Paula Souza – CEETEPS. Eletricista formado pela escola SENAI para atuação em CMRDA e Smart Meter (medidores inteligentes).


