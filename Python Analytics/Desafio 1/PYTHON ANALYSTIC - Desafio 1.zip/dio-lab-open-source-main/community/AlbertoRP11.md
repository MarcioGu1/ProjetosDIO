# Alberto R. Peruchi

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alberto-rp/)

## Habilidades
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
