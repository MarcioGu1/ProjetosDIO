# Alailson Nascimento 😄

🌎Hello world🌎, sou o Alailson Nascimento, fascinado pela cultura Geek é estudante de Análise e Desenvolvimento de sistemas, busco cada vez  mais oportunidades para adquirir  conhecimento e experiência na área da tecnologia da informação com foco em desenvolvimento front end. permitindo meu crescimento intelectual, profissional e técnico.

## Conecte-se comigo
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alailson-nascimento/)


## 🛠 Habilidades

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
#
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
#
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

# GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alailsonn&theme=transparent&bg_color=00FFFF&border_color=0000FF&show_icons=true&icon_color=4B0082&title_color=0000FF&text_color=FF0000)
