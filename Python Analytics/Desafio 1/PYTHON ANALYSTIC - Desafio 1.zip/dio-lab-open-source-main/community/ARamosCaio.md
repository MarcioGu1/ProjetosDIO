# ARamosCaio

Olá, sou o Caio, Dev backend focado em python e Java.

Desenvolvi alguns projetos em Python visando desenvolvimento web e atualmente estou aprendendo java.

## Conecte-se Comigo

<a href = "https://instagram.com/caio_var" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
<a href = "https://www.linkedin.com/in/caio-vinicius-araujo-ramos/"><img src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white"></a>

## Habilidades

<img src="https://img.shields.io/badge/Python-14354C?style=for-the-badge&logo=python&logoColor=white" />
<img src="https://img.shields.io/badge/Django-092E20?style=for-the-badge&logo=django&logoColor=white" />
<img src="https://img.shields.io/badge/Flask-000000?style=for-the-badge&logo=flask&logoColor=white"  /> 

## Github Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=ARamosCaio&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Linguagens Mais Utilizadas

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=ARamosCaio&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)
