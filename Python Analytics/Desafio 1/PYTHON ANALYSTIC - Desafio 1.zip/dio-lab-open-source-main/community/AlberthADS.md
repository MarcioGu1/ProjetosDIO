# Quem Sou Eu? 🤔

Olá! Eu sou o **AlberthADS**, um **Analista de Infraestrutura** apaixonado por tecnologia e redes. Aqui está um breve resumo sobre mim:

## Minha Atuação 🛠️

Como Analista de Infraestrutura, minhas tarefas incluem:

- **Gerenciamento de Redes** 🌐: Configuro e otimizo redes para garantir conectividade confiável.
- **Administração de Servidores** 💻: Mantenho servidores funcionando sem problemas, aplicando atualizações e ajustando configurações.
- **Automatização com Powershell** 💾: Escrevo scripts para automatizar tarefas repetitivas.
- **API co NodeJS** 🎯: Adoro desenvolver pequenas aplicações usando NodeJS.
- **Apaixonado por Cisco** 🔃: Trabalho com equipamentos Cisco para criar redes robustas.

## Meus Hubs 🌟

- 🎮 **Video-game**: Sou um gamer nas horas vagas, explorando mundos virtuais e desafiando chefes.
- 💻 **PC**: Adoro montar e otimizar PCs para obter o melhor desempenho.
- 🌐 **Redes**: Redes são minha paixão; adoro aprender sobre roteadores, switches e protocolos.
- ⚽ **Futebol**: Sou um torcedor fervoroso e nunca perco um jogo do meu time favorito.

Se você compartilha alguma dessas paixões, vamos trocar ideias! 😊.
