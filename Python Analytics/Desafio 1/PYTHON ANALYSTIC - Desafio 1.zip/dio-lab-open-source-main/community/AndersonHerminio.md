# Olá! Sou Anderson Herminio

Com uma década de experiência em refrigeração comercial e industrial, a pandemia motivou minha transição para a área de Desenvolvimento de Software. 
Desde 2021, dedico-me ao desenvolvimento de software, culminando na posição atual de Desenvolvedor Full Stack 🧠. 

Meu crescimento é constante, e estou animado por contribuir e aprender no dinâmico universo da programação.


## 🔗 Links

[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/anderson-herm%C3%ADnio-620867232/)



## 🛠 Skills - Habilidades em desenvolvimento
- ![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
- ![Angular](https://img.shields.io/badge/Angular.JS-DD0031?style=for-the-badge&logo=angular&logoColor=white)
- ![Sequelize](https://img.shields.io/badge/Sequelize-0175C2?style=for-the-badge&logoColor=white)
- ![NODE.JS](https://img.shields.io/badge/NODE.JS-239120?style=for-the-badge&logoColor=white)
- ![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
- ![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
- ![PostgreSQL](https://img.shields.io/badge/PostgreSQL-000?style=for-the-badge&logo=postgresql)
- ![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)
