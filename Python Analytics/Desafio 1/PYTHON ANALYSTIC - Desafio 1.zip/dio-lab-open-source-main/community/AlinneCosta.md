<div align="center">
<h1>  Olá sou Aline Costa
   <img src="https://github.com/AlinneCosta/hello-world/assets/109036666/a69dc5ec-c1e2-4198-a6fc-40d367074ee1"width="100px"/>
</h1>
</div>

   Iniciando na carreira como desenvolvedora front-end.
Apaixonada por tecnologia, iniciei meus estudos de forma autoditada, o que me proporcionou conhecimento, de forma superficial, das tecnologias digitais existentes, para que cada uma serve e em qual contexto estão inseridas.
  No momento, estou exercendo a minha primeira profissão e meu maior desafio será conciliar estas duas profissões.

Na DIO [https://www.dio.me/en] encontrei a oportunidade de me aprofundar nos conhecimentos essenciais para a minha atuação em front-end.

No momento buscando desenvolver as seguintes habilidades, através dos bootcamps da Digital Innovation One:

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

[https://www.dio.me/en/bootcamp/potencia-tech-ifood-programacao-do-zero]

[https://www.dio.me/careers/front-end]

## Habilidades
![GIT](https://img.shields.io/badge/GIT-000?style=for-the-badge&logo=git&logoColor=777884)
![GITHUB](https://img.shields.io/badge/GITHUB-000?style=for-the-badge&logo=github&logoColor=777884)
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
![EXCEL](https://img.shields.io/badge/EXCEL-000?style=for-the-badge&logo=excel&logoColor=777884)

## Mais sobre mim:

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/aline-costa-865863298/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/AlinneCosta)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/alinegcostati/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=007BFF)](mailto:alinegcostadev@gmail.com)
