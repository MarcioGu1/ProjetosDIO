 # Olá! eu sou Antonio Romes 👋🏻
 
 ## Sobre mim
 
- 📚 Sou formado em Ciência da Computação
- 👨 Desenvolvedor web Front-End e Back-End;
    
## 📲 Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/antonioromes1?tab=achievements)
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/gabriel-pires-947bb1252/)
[![LinkedIn](https://img.shields.io/badge/-instagram-000?style=for-the-badge&logo=instagram&logoColor=30A3DC)](https://www.instagram.com/antonio_romes_lima/)

## 💻 Habilidades

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5&logoColor=30A3DC)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=E94D5F)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=30A3DC)
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085) 
![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react) 
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)


![Antonio-Romes GitHub stats](https://github-readme-stats.vercel.app/api?username=Antonio-Romes&show_icons=true&theme=highcontrast)
![Most Used Languages](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Antonio-Romes&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## 📌 Projetos em Destaque
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Antonio-Romes&repo=Racha_Cuca&bg_color=1a1b27&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=7957d5&text_color=fff)](https://github.com/Antonio-Romes/Racha_Cuca) 
