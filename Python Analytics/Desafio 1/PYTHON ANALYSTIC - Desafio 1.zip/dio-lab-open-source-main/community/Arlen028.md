
#  🔹Olá! Eu sou o Arlen Agra 🖐🏽🔹

> <p> Ao seu dispor </p>



## ⚙️ Tecnologias
[//]: # (Variáveis para os links das imagens)
[html-badge]: https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white
[css-badge]: https://img.shields.io/badge/css-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white
[js-badge]: https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E
[ts-badge]: https://img.shields.io/badge/typescript-%23007ACC.svg?style=for-the-badge&logo=typescript&logoColor=white
[react-badge]: https://img.shields.io/badge/react-%2320232a.svg?style=for-the-badge&logo=react&logoColor=%2361DAFB
[git-badge]: https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white
[github-badge]: https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white
[kotlin-badge]:https://img.shields.io/badge/Kotlin-0095D5?&style=for-the-badge&logo=kotlin&logoColor=white
[ps-badge]:https://img.shields.io/badge/Adobe%20Photoshop-31A8FF?style=for-the-badge&logo=Adobe%20Photoshop&logoColor=black
[figma-badge]:https://img.shields.io/badge/Figma-F24E1E?style=for-the-badge&logo=figma&logoColor=white
[angular-badge]: https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white

|  |  |  |
|:---:|:---:|:---:|
| ![HTML][html-badge] | ![CSS][css-badge] | ![Adobe Photoshop][ps-badge] |
| ![JavaScript][js-badge] | ![TypeScript][ts-badge] | ![Figma][figma-badge] |
| ![React][react-badge] |  ![Angular][angular-badge] | ![Github][github-badge] ![Git][git-badge]  |



## 📱 Minhas rede sociais 
[<img src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white">](https://www.linkedin.com/in/arlen-agra-571275209/)
[<img src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white">](mailto:arlens527@gmail.com)
[<img src="https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white">]()

> <p> Não espere o futuro mudar tua vida, porque o futuro será a consequência do presente. </p>
