
# 👋 Olá!, Sou Andrielly Rocha
📚 Eu estou cursando Sistemas de Informação e sempre procuro aprender mais para melhorar minhas habilidades.

### 🤝 Conecte-se comigo
[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-000?style=for-the-badge)](https://www.dio.me/users/andrielly_farias21)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/andrifarias/)


### 🧠 Habilidades
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)


### 📊 GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AndriFarias&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=6a00b0&text_color=FFF)
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AndriFarias&layout=compact&bg_color=000&border_color=6a00b0&title_color=6a00b0&text_color=FFF)


