# Thiago Adorno Here!🌧️
## **About me**
---
**(PT/BR):**  
Oi, pode me chamar de Adorno. Eu sou um estudante de programação que é apaixonado por aprender. Se quiser me ensinar alguma coisa, dê uma olhada na aba **_Social_**.  
##### **Passatempos**
* Tocar guitarra;
* Estudar programação;
* Ler;
* Ouvir Música;
* Jogar;
* Ir à academia.

**(EN/US):**  
Hi, you can call me Adorno. I'm a programming student who is passionate about learning. If you wanna teach me something, check out the **_Social_** tab.

##### **Hobbys**
* Play guitar;
* Estudy programming;
* To read;
* Listen to music;
* Play video games;
* Go to the gym.

## **Social**
---
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/thiago-adorno-705409253/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/t.adorn0/)

## **Known Languagens**
---
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![C](https://img.shields.io/badge/Advpl-000?style=for-the-badge&logo=Advpl)

![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)

![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)

## **GitHub Status**
---
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Ad0rn0&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## **Languages Ranking**
---
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Ad0rn0&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## **Study Repository**
---
#### Repositório forked para estudo do curso de Git e GitHub da DIO
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Ad0rn0&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Ad0rn0/dio-lab-open-source)

