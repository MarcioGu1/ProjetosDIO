### Olá, sou a Andréia Carla (AndreiaCarla)
Professora de Matemática do Ensino Fundamental e Médio.
## Atuação Profissional
- Analista técnica no Departamento de Nutrição e Alimentação Escolar do Estado do Paraná.
- INSTITUTO PARANAENSE DE DESENVOLVIMENTO EDUCACIONAL – FUNDEPAR [https://www.fundepar.pr.gov.br]
