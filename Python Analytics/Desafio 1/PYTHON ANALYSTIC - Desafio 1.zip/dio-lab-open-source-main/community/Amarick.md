### Hello there! 👋

Olá! Meu nome é Victor, mas você pode me chamar pelo meu nickname, Amarick!
- Sou um estudante de Engenharia da Computação apaixonado por tecnologia e sempre buscando aprender mais sobre o mundo dos devs.
----------------------------------------------------------------------------------
Aqui estão alguns detalhes sobre mim:

### hobbies
Tenho alguns hobbies que são fundamentais para meu equilíbrio entre estudos e lazer:

Astronomia: Desde criança, sempre me fascinei pelo cosmos e as maravilhas do universo. Adoro observar estrelas, planetas e aprender sobre astrofísica sempre que posso.

Musculação: Além de minha paixão pela tecnologia, também dedico parte do meu tempo ao treinamento físico. A musculação me ajuda a manter um corpo saudável e equilibrado, proporcionando uma ótima contrapartida para minhas horas de estudo.
  
----------------------------------------------------------------------------------

# :computer: Desenvolvedor Front-End!

## :house_with_garden: Localização

- Baixada Santista, litoral de São Paulo - BR.
