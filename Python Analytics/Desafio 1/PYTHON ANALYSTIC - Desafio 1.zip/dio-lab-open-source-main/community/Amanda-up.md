# Amanda Rafaela
    Analista de Sistemas Jr


## Redes Sociais
[![LinkedIn](https://img.shields.io/badge/LinkedIn-9400D3?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/amanda-rafaela-6153791b2/)


### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Amanda-up&theme=transparent&bg_color=9400D3&border_color=FFF&show_icons=true&icon_color=FFF&title_color=FFF&text_color=FFF)