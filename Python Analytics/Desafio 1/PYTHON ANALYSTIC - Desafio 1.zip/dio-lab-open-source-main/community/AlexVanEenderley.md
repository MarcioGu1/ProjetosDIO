<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=CCFF33&height=120&section=header"/>

[![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=CCFF33&size=35&center=true&vCenter=true&width=1000&lines=Olá,+bem+vindo+ao+meu+perfil.;Sou+Alex+Wanderley;Desenvolvedor+de+games;Moro+em+Natal-RN+Brasil)](https://git.io/typing-svg)

<div align="center">  
  <img width="49%" height="195px" src="https://github-readme-stats.vercel.app/api?username=alexvaneenderley&show_icons=true&count_private=true&hide_border=true&title_color=00bfbf&icon_color=00bfbf&text_color=c9d1d9&bg_color=0d1117" alt="Marina Jaudy´s GitHub Stats"/>
  <img width="41%" height="195px" src="https://github-readme-stats.vercel.app/api/top-langs/?username=alexvaneenderley&layout=compact&hide_border=true&title_color=00bfbf&text_color=00bfbf&bg_color=0d1117" />
</div>

<p align="center">
  <img src="https://github-profile-trophy.vercel.app/?username=alexvaneenderley&theme=dracula&row=2&no-bg=true&column=3&margin-w=15&margin-h=15" />
</p>

<div align="center">  
<a href="https://instagram.com/alex_van_eenderley" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
<a href="https://www.linkedin.com/in/alex-wanderley/" target="_blank"><img src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white"></a></div>

## Um pouco sobre mim

Sou aspirante a desenvolvedor de jogos, com mais experiência em design de levels. Estou fazendo um Bootcamp Potência Tech iFood - Desenvolvimento de Jogos, tendo experiência em projetos práticos individuais, utilizando tecnologias como HTML, CSS, Unreal Engine e outras.<br>

Sou gastrólogo, adoro cozinhar, trabalhei em diversos restaurantes pelo Rio Grande Do Norte. Sempre gostei de moda, e as vezes me inspiro a fazer roupas utilizando a técnica do Tie Die, o que me faz meditar a respeito da jornada da vida. No meio dessas meditações, em um processo de brainstorming, me vi em transição de carreira para a área de tecnologia.<br>

Foi nesse momento, que entendi o porque a tecnologia entrou na minha vida, por gostar de games e isso sempre ter feito parte da minha vida, tendo sido passado de pai para filho. Me aprofundando mais sobre esse tema,decidi iniciar os meus estudos no Bootcamp Potência Tech iFood - Desenvolvimento de Jogos.

### Main skills:

<!-- <code><img width="4%" src="https://raw.githubusercontent.com/tandpfun/skill-icons/d1c752b99bb25a0e5aa363bae1db2809173ee966/icons/JavaScript.svg"></code> -->
<!-- <code><img width="4%" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/typescript/typescript-original.svg"></code> -->
<code><img width="4%" src="https://raw.githubusercontent.com/tandpfun/skill-icons/d1c752b99bb25a0e5aa363bae1db2809173ee966/icons/HTML.svg"></code>
<code><img width="4%" src="https://raw.githubusercontent.com/tandpfun/skill-icons/d1c752b99bb25a0e5aa363bae1db2809173ee966/icons/CSS.svg"></code>
  
##
  ### Tools:
  <code><img width="4%" src="https://cdn-icons-png.flaticon.com/512/733/733553.png"></code>
  <code><img width="4%" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original.svg"></code>
  <code><img width="4%" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg"></code>
   <code><img width="8%" src="https://img.shields.io/badge/-Unreal%20Engine-313131?style=for-the-badge&logo=unreal-engine&logoColor=white"></code>
   <code><img width="8%" src="https://img.shields.io/badge/Epic%20Games-313131?style=for-the-badge&logo=Epic%20Games&logoColor=white"></code>
   <code><img width="8%" src="https://img.shields.io/badge/Steam-000000?style=for-the-badge&logo=steam&logoColor=white"></code>
  <!-- <code><img width="4%" src="https://raw.githubusercontent.com/tandpfun/skill-icons/d1c752b99bb25a0e5aa363bae1db2809173ee966/icons/Unity-Dark.svg"></code> -->
  <!-- <code><img width="4%" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg"></code> -->
  <code><img width="4%" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/figma/figma-original.svg"></code>  <br>
  
  <!-- <code><img width="4%" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg"></code> -->
  <!-- <code><img width="4%" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg"></code> -->
  
  
##
### Studying in this moment:
  Design de levels
  JavaScript
  Desenvolvimento de games
  Unreal Engine