<div align="center">
  <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="30" />
  <h1>Hi, there!</h1>
</div>

<div align="center">
  <p>
    <a href="https://www.linkedin.com/in/allan-debastiani/">
      <img src="https://img.shields.io/badge/-LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white" />
    </a>
  </p>
</div>

<div align="center">
  <p>
    <a href="https://github.com/Allandeba?tab=repositories&sort=stargazers">
      <img alt="total stars" title="Total stars on GitHub" src="https://custom-icon-badges.herokuapp.com/badge/dynamic/json?logo=star&color=55960c&labelColor=488207&label=Stars&style=for-the-badge&query=%24.stars&url=https://api.github-star-counter.workers.dev/user/Allandeba" />
    </a>
    <a href="https://github.com/Allandeba?tab=followers">
      <img alt="followers" title="Follow me on Github" src="https://custom-icon-badges.herokuapp.com/github/followers/Allandeba?color=236ad3&labelColor=1155ba&style=for-the-badge&logo=person-add&label=Follow&logoColor=white" />
    </a>
    <a href="https://github.com/Allandeba/">
      <img alt="Views" title="GitHub profile views" src="https://komarev.com/ghpvc/?username=Allandeba&label=Profile%20Views&color=red&style=for-the-badge" />
    </a>
  </p>
</div>

<div align="center">
  <p>
    <img src="https://img.shields.io/badge/C%23-239120?style=for-the-badge&logo=c-sharp&logoColor=white" />
    <img src="https://img.shields.io/badge/Blazor-5C2D91?style=for-the-badge" />
    <img src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black" />
    <img src="https://img.shields.io/badge/HTML-E34F26?style=for-the-badge&logo=html5&logoColor=white" />
    <img src="https://img.shields.io/badge/CSS-1572B6?style=for-the-badge&logo=css3&logoColor=white" />
    <img src="https://img.shields.io/badge/RESTful%20APIs-30A3DC?style=for-the-badge" />
    <img src="https://img.shields.io/badge/Scrum-30A3DC?style=for-the-badge" />
    <img src="https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=git&logoColor=white" />
    <img src="https://img.shields.io/badge/Tortoise%20SVN-810B14?style=for-the-badge&logo=apache-subversion&logoColor=white" />
    <img src="https://img.shields.io/badge/Docker-<COLOR>?style=for-the-badge&logo=docker" />
  </p>
</div>

<br />

<div align="center">
  <p>
    <a href="https://github.com/Allandeba" target="_blank">
      <img width="400" src="https://github-readme-stats.vercel.app/api?username=Allandeba&show_icons=true&theme=react" alt="Allandeba's Stats" />
      <img width="335" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Allandeba&layout=compact&theme=react" alt="Used Languages" />
    </a>
  </p>
</div>
