# Oi, meu nome é Ana Beatriz!
Sou uma programadora iniciante que a cada dia se apaixona mais pela área de tecnologia.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/ana-beatriz-silva-araujo-30aa2927b/)

## Habilidades
![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c) 
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AnnBtz21937&theme=transparent&bg_color=000&border_color=7fffd4&show_icons=true&icon_color=30A3DC&title_color=7fffd4&text_color=FFF)

## Meus projetos DIO
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AnnBtz21937&repo=DIO-lab-open-source&bg_color=000&border_color=7fffd4&show_icons=true&icon_color=30A3DC&title_color=7fffd4&text_color=FFF)](https://github.com/AnnBtz21937/DIO-lab-open-source)