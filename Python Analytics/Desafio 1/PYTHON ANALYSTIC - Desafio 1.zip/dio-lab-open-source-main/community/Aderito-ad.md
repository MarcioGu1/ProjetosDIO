
# 👋 hello!! 
## 😊 welcome to my profile
My name is Aderito, I'm a technology student and I really enjoy learning about systems development.
my dream and goal is to become a full stack 
programmer
This is my first training experience at DIO and I'm loving it


 ## 🗯 my contact
 

<div>

[![Linkedin](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/aderito-francisco-8a2a75230/) 
[![Gmal](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](aderitoadestar@gmail.com)[![WhatsApp](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)]()

</div>

<br>


## 🛠 technologies
<div>


<img align="center" alt="HTML5" src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white">
<img align="center" alt="CSS3" src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white">
<img align="center" alt="Javascript" src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black">
<img align="center" alt="React" src="https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB">
<img align="center" alt="mySQL" src="https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white">
<img align="center" alt="Java" src="https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white">

</div>





<br>

[![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=Aderito-ad)](https://github.com/anuraghazra/github-readme-stats)

</div>