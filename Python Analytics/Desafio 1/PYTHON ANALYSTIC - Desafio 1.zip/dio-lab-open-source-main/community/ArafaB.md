### Olá, me chamo Anna Rafaella! 😊

**Sou Técnica em Informática, formada pelo Instituto Federal da Bahia**

### Meu Git 🐈‍⬛

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=ArafaB&theme=radical&show_icons=true)

### Meus Projetos 📂

[![Site-Vagas-MulheresInTech](https://github-readme-stats.vercel.app/api/pin/?username=ArafaB&repo=Site-Vagas-MulheresInTech&theme=radical)](https://github.com/ArafaB/Site-Vagas-MulheresInTech)

### Top Linguagens 

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=ArafaB&theme=radical&layout=compact)
