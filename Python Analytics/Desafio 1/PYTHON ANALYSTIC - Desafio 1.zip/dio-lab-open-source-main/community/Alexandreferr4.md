# Alexandreferr4

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/alexandre-ferreira-880746285/)
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/alex_ferreiras/)
[![GitHub](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=github)](https://github.com/Alexandreferr4?tab=repositories)

## Habilidades
### Linguagens de marcação:
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
### Linguagens de programação
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Jupyter](https://img.shields.io/badge/jupyter-000?style=for-the-badge&logo=jupyter)
![Django](https://img.shields.io/badge/Django-000?style=for-the-badge&logo=django)
![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alexandreferr4&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF_title-true&hide=stars)

## Minhas Contribuições
[![GitHub Streak](https://streak-stats.demolab.com/?user=Alexandreferr4&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)