# Antonio Gomes Dos Reis Neto

Sou estudande de Engenharia Mecânica, no curso eu vi que tem muita automação, com isso me chamou a atençao a parte de programação, eu gostei e decidi ir atras de como funcionava e aqui estou eu aprendendo na DIO-Digital Innovation One. 

### Conecte-se comigo

[![Perfil DIO](https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge)](https://web.dio.me/users/reisgomes222_1)

[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:reisgomes222@outlook.com)


### Habilidades



[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://github.com/Antonio953547)



### Meus Principais Desafios de Projeto DIO


[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=elidianaandrade&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Antonio953547/dio-lab-open-source)