# Alex Martins
Hi There!! Eu sou Alex Martins, sou professor de inglês e desenvolvedor full-stack

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=30A3DC)](https://www.linkedin.com/in/alexsmartinc/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:alex.smc@hotmail.com)
[![GitHub](https://img.shields.io/badge/-GitHub-000?style=for-the-badge&logo=GitHub&logoColor=30A3DC)](https://www.github.com/alexsmc/)

## Habilidades

[![Python](https://img.shields.io/badge/-Python-000?style=for-the-badge&logo=Python&logoColor=30A3DC)]()
[![GIT](https://img.shields.io/badge/-Git-000?style=for-the-badge&logo=Git&logoColor=30A3DC)]()
[![GitHub](https://img.shields.io/badge/-GitHub-000?style=for-the-badge&logo=GitHub&logoColor=30A3DC)]()
[![HTML](https://img.shields.io/badge/-HTML-000?style=for-the-badge&logo=HTML5&logoColor=30A3DC)]()
[![CSS](https://img.shields.io/badge/-CSS-000?style=for-the-badge&logo=CSS3&logoColor=30A3DC)]()
[![JavaScript](https://img.shields.io/badge/-JavaScript-000?style=for-the-badge&logo=JavaScript&logoColor=30A3DC)]()

## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Alexsmc&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Minhas contribuições

[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=Alexsmc&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Alexsmnc/dio-lab-open-source)