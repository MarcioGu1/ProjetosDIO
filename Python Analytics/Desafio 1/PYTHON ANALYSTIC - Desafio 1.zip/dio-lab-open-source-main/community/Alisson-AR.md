### Este é o perfil de Alisson Rosa, seja bem vindo!
- 🌱 Dev Front End, HTML / CSS3 / JS / ANGULAR.
- 📚 Lifelong learning.

##

<div>
  <a href="https://github.com/Alisson-AR">
    <img height="150em" src="https://github-readme-stats.vercel.app/api?username=Alisson-AR&count_private=true&include_all_commits=true&show_icons=true&theme=github_dark&hide_border=false&show_owner=true"/>
    <img height="150em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Alisson-AR&theme=github_dark&hide_border=false&&layout=compact"/>
  </a>
</div>

<div style="display: inline_block"><br>
  <img align="center" alt="HTML" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original.svg">
  <img align="center" alt="CSS" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original.svg">
  <img align="center" alt="Js" height="30" width="40" src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-plain.svg">
  <img align="center" alt="Js" height="30" width="40" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg" height="40" width="52" alt="java logo">
</div>

##

<div>
  <a href="https://www.linkedin.com/in/alisson-rosa-309659226" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
  <a href = "mailto:alisson.aln.rosa@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.instagram.com/venfroz_/" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
</div> 
