# Bem-Vindos!

## Meu Perfil

### Sobre

Olá, amigos, gostaria de me apresentar um pouco. Meu  nome é Albert Felix, tenho 27 anos e nem sempre fiz parte do mundo da tecnologia. Cursei até o 6° período Filosofia e um dia decidi mudar de área. Com apoio de amigos e porque gostei de explorar esse universo complexo da tecnologia decidi começar Análise e Desenvolvimento de Sistemas (atualmente segundo semestre). Tem sido desafiador, mas tenho me saído bem. Gosto de ler, aprender novas linguagens, entender como funciona a internet e nos tempos vagos, jogos, além de um particular interesse por CyberSecurity, pois acredito que desenvolver deve estar alinhado às normas de segurança cibernética. Num mundo que não pode mais se imaginar sem tecnologia, sua segurança garantirá sua continuidade...

### Habilidades

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)

### Conecte-se comigo

[![Github](https://img.shields.io/badge/Github-357?style=for-the-badge&logo=Github&logoColor=0E76A8)](https://github.com/AltFLX27)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-357?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/altfelix)





