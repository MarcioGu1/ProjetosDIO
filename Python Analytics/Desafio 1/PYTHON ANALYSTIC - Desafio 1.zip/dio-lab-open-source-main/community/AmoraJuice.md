# AmoraJuice 🫐
        "Eu tentei 99 vezes e falhei, mas na centésima tentativa eu consegui, nunca desista de seus objetivos mesmo que esses pareçam impossíveis, a próxima tentativa pode ser a vitoriosa." 
            -Albert Einstein
## Mais conhecido como Amaral
Oi, me chamo Gustavo Amaral de apelido simples só Amaral, e com a chegada de 2022 venho dando um destaque cada vez maior para tecnologia e programação na minha vida. Com meus 18 anos ainda vejo programação como um *Hobby* porém nunca deixando de aprender mais e mais.

## Contato
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=fff)](https://github.com/AmoraJuice)
[![Perfil DIO](https://img.shields.io/badge/DIO-000?style=for-the-badge&logo=dio)](https://www.dio.me/users/gustavoamaraldcruz/)
[![Gmail](https://img.shields.io/badge/Gmail-000?style=for-the-badge&logo=gmail&logoColor=fff)](gustavoamaraldcruz@gmail.com)
[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord&logoColor=fff)](amaralfqz)

## Status
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AmoraJuice&bg_color=000&border_color=ffff00&title_color=00ffff&text_color=ffff00)
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AmoraJuice&theme=transparent&bg_color=000&border_color=0000ff&show_icons=true&icon_color=0080ff&title_color=8000ff&text_color=FFF)


## Projetos
[![Repo DIO](https://github-readme-stats.vercel.app/api/pin/?username=elidianaandrade&repo=dio-lab-open-source&bg_color=000&border_color=E94D5F&show_icons=true&icon_color=30A3DC&title_color=30A3DC&text_color=FFF)](https://github.com/elidianaandrade/dio-lab-open-source)
[![Repo DIO](https://github-readme-stats.vercel.app/api/pin/?username=AmoraJuice&repo=Java-GerenciamentoDBiblioteca-Project&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/AmoraJuice/Java-GerenciamentoDBiblioteca-Project.git)

[![Repo DIO](https://github-readme-stats.vercel.app/api/pin/?username=AmoraJuice&repo=Projeto-ConversorTemperatura-Python&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/AmoraJuice/Projeto-ConversorTemperatura-Python.git)
[![Repo DIO](https://github-readme-stats.vercel.app/api/pin/?username=AmoraJuice&repo=Projeto-SiteDcompras-Java-Html&bg_color=000&border_color=E94D5F&show_icons=true&icon_color=30A3DC&title_color=30A3DC&text_color=FFF)](https://github.com/AmoraJuice/Projeto-SiteDcompras-Java-Html.git)