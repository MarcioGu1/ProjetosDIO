# Olá, Meu nome é Ângelo.

## Sobre Mim
Sou um estudante de programação em JAVA, possuo pouco tempo de experiência porém muito empenho em aprender para me desenvolver cada vez mais.


## 📚Educação

### Técnologo em ADS
Universidade Uninter, Ano de Conclusão: 2025


## 🛠Habilidades

### Soft Skills

- Aprende rapidamente
- Gestão de projetos
- Proatividade
- Flexibilidade
- Capacidade de trabalho em equipe
- Criatividade

### Hard Skills

- Conhecimento básico em JAVA
- Familiaridade com o Inglês
- Noções de database
- Conhecimento em Github

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AngeloBages&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)



## 📞Contato

- Email: angelobandeira55555@gmail.com
- LinkedIn: [Ângelo Bages](https://www.linkedin.com/in/ângelo-bages-47a324261)
- GitHub: [Ângelo Bages](https://github.com/AngeloBages)
