# Olá pessoas! Me chamo Geovani
A um bom tempo sou apaixonado por linux, e atualmente o tenho como meu sistema principal. Minha distribuição favorita é o Debian, e é a que uso atualmente.Sendo assim já estou bem familiarizado com comandos em terminal (aliás, estou editando este arquivo pelo Vim) e com o conceito de código aberto. Apesar de beber muito da fonte do open source, nunca me aprofundei muito em temas como git e github. Até agora...
 Posso dizer que estou gostando muito destes novos aprendizados, e com certeza estes serão muito úteis no meu dia a dia. Não trabalho na área de tecnologia, sou apenas um entusiasta. porém, quem sabe...
***
## Sistema Operacional

![Linux](https://img.shields.io/badge/Linux-000?style=for-the-badge&logo=linux&logoColor=FCC624)

