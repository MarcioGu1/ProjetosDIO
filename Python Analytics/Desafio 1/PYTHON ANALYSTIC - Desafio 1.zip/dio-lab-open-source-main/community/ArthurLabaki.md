# Olá, eu sou Arthur Labaki 👋

### Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/arthurlabaki/) 

### 🌌 Soft Skills

![Static Badge](https://img.shields.io/badge/Organizado-7B68EE)
![Static Badge](https://img.shields.io/badge/Resolução%20de%20Conflitos-9370DB)
![Static Badge](https://img.shields.io/badge/Gerenciamento%20de%20Tempo-8A2BE2)
![Static Badge](https://img.shields.io/badge/Criativo-4B0082)

### 📊 Estatísticas no GitHub

![ArthurLabaki's GitHub stats](https://github-readme-stats.vercel.app/api?username=ArthurLabaki&show_icons=true&theme=dracula)

### 🚀 Linguagens Mais Usadas

![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=ArthurLabaki&layout=compact)


