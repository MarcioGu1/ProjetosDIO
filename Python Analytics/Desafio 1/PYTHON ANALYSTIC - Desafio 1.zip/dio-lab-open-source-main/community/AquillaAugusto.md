Function Mensagem(){

## Introdução

    Muito Prazer meu nome é Áquilla e estou ansioso para começar minha carreira no mundo da programação.
    Graças a meu amor pelos computadores e desafios, quando trabalho com eles não me sinto estressado ou esgotado. De certa maneira me divirto tentando resolver problemas ou fazer algo melhor e mais elaborado.
    Sou bem Objetivo e Direto, então tendo a ter dificuldades para adicionar detalhes em meus projetos, mas tendo a prestar atenção para que isso não prejudique meu projeto e não fique apenas funcional.

## Objetivos

    - Entrar na Área Profissional como um FullStack;
    - Criar relações com outros programadores e fazer projetos juntos;
    - Aprender principalmente sobre IA's e Machine learning;
    - Ser um programador Capaz e Autosuficiente;

## Mensagem Final

    Com essa pequena introdução me dispeço e agradeço pela sua atenção nessa leitura. Caso queira me siga no GitHub https://github.com/AquillaAugusto, será um prazer ter sua companhia.
    Ah!! E caso saiba alguma coisa interessante sobre IA's ou Machine Learning, por favor me Deixe Saber. Muito Obrigado :P

END
}

Mensagem();