
# # 👋 Olá, sou o Brendo - ArcanjoSUP

Seja bem-vindo ao meu mundo de códigos e inovação! 🚀 Meu nome é Brendo, mas muitos me conhecem como ArcanjoSUP, A alcunha reflete minha paixão por ajudar as pessoas, uma característica que valorizo profundamente.

## 👨‍💻 Quem sou eu

Atualmente, sou um estudante entusiasta da Universidade Católica de Brasília, imerso no curso de Análise e Desenvolvimento de Sistemas. Adoro desbravar os desafios do código e sou movido pela curiosidade incessante de aprender coisas novas.

## 💡 Explorando o Universo Tecnológico

Minha jornada no mundo da tecnologia é alimentada por uma paixão que cresce desde sempre. Estou em constante busca de aprimoramento, desbravando as fronteiras da inovação e transformando ideias em soluções tangíveis.

## 🌐 Conecte-se comigo

- [![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/brendo-passos-725495227/)
- [![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/ArcanjoSUP)
- [![Gmail](https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red)](mailto:brendo.rochasup@gmail.com)
## 🚀 Vamos Criar Algo Incrível Juntos!

Estou sempre aberto a novas colaborações e desafios emocionantes. Se você tem uma ideia, um projeto, ou apenas quer bater um papo sobre tecnologia, não hesite em entrar em contato. Vamos construir o futuro juntos!

---

Agradeço por visitar meu cantinho digital! 👾✨
