# Alan Eduardo 
Olá, eu sou Alan Eduardo, sou formado na área de engenharia elétrica, estou em transicão de carreeira para área de tenologia, atualmente estou realizando  BootCamps na DIO  e realizando curso de Full Stack pela plataforma DevClub.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/aeduardocruz/)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=0E76A8)](https://github.com/AlanEduardoCruz)

## Habilidades
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)


## Próximas Tecnologias
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)

## GitHub Status
![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=AlanEduardoCruz&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)


## Minhas contribuições 
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AlanEduardoCruz&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/AlanEduardoCruz/dio-lab-open-source)



