# 👋🏻 Olá, meu nome é Andressa Silva
##
### ✌🏻 Seja bem vindo ao meu perfil 🌌
##
_Sou desenvolvedora FullStack em constante evolução, autodidata em Ciência de Dados, meu objetivo futuramente é desenvolver IA Generativas, sou pesquisadora e cientista na área da computação pelo Instituto de Educação, Ciência e Tecnologia do Maranhão, também quero me especializar em Física Computacional_
##
## 📲 Conecte-se comigo
<div> 
  <a href="https://web.dio.me/users/andressasp68?tab=achievements" target="_blank"><img src="https://img.shields.io/badge/-Meu%20Perfil%20na%20DIO-30A3DC?style=for-the-badge" target="_blank"></a>
  <a href="https://instagram.com/andressa.saturn?igshid=MTIyMzRjYmRlZg==" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white" target="_blank"></a>
 	<a href="https://www.twitch.tv/andressasaturn" target="_blank"><img src="https://img.shields.io/badge/Twitch-9146FF?style=for-the-badge&logo=twitch&logoColor=white" target="_blank"></a>
  <a href = "mailto:andressasp68@gmail.com"><img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
  <a href="https://www.linkedin.com/mwlite/in/andressa-silva-29430a218" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
<a href="https://twitter.com/saturn_girlxxxx?t=wGEM85jVCe-lnfrveO51SQ&s=09" target="_blank"><img src="https://img.shields.io/badge/Twitter-1DA1F2?style=for-the-badge&logo=twitter&logoColor=white"></a>
</div>

##
## 👩🏻‍💻 Habilidades
![HTML](https://img.shields.io/badge/HTML-000?style=for-the-badge&logo=html5&logoColor=30A3DC)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=E94D5F)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript&logoColor=F0DB4F)
![Angular](https://img.shields.io/badge/Angular-DD0031?style=for-the-badge&logo=angular&logoColor=white)
![Python](https://img.shields.io/badge/Python-14354C?style=for-the-badge&logo=python&logoColor=white)
![Django](https://img.shields.io/badge/Django-092E20?style=for-the-badge&logo=django&logoColor=white)
![SQLITE](https://img.shields.io/badge/SQLite-07405E?style=for-the-badge&logo=sqlite&logoColor=white)
![Jupyter Notebook](https://img.shields.io/badge/jupyter-%23FA0F00.svg?style=for-the-badge&logo=jupyter&logoColor=white)
[![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git&logoColor=E94D5F)](https://git-scm.com/doc)
[![GitHub](https://img.shields.io/badge/GitHub-000?style=for-the-badge&logo=github&logoColor=30A3DC)](https://docs.github.com/)

##
## 📊 GitHub Stats
<a href="https://github.com/AndressaSilva0"><img alt="Dunsin's Github Stats" src="https://github-readme-stats.vercel.app/api?username=AndressaSilva0&show_icons=true&count_private=true&theme=dracula" /></a>
<a href="https://github.com/AndressaSilva0"><img alt="Dunsin's Top Languages" src="https://github-readme-stats.vercel.app/api/top-langs/?username=AndressaSilva0&langs_count=8&count_private=true&layout=compact&theme=dracula"/></a>

##
## 📋 Meus Desafios de Projeto com a DIO
[![Repo DIO Git GitHub](https://github-readme-stats.vercel.app/api/pin/?username=elidianaandrade&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/elidianaandrade/dio-lab-op)
