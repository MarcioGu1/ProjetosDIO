# Oi, eu sou a Anna Victoria! 👋

 
## 🔗 Links
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/anna-fernandes-77a05b198/)
[![instagram](https://img.shields.io/badge/instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/_annafernandes__/)


## 
👩‍💻 Estou a procura de trabalho
