
# Apoena Avelar
Bem vindos, esse conteúdo faz parte do bootcamp da DIO na carreira fullstack. sou formado em Ciência da computação, pós graduado em redes de computador e telecomunicações, tenho MBa em gestão de negócios e atualmente atuo como gestor de equipes. A algum tempo venho desenhando essa transição de carreira e estou muito empolgado com esse início de jornada.


## Habilidades
|  ![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5) | ![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)   |  ![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript) |
|:-:|:-:|:-:|
|  ![Git](https://img.shields.io/badge/Git-000?style=for-the-badge&logo=git) | ![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=Github)  |   |

 

## Estatísticat Github
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=ApoenaAvelar&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)


## Contatos
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](www.linkedin.com/in/apoena-avelar-53641357)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=E94D5F)](mailto:apoenajorge@gmail.com)