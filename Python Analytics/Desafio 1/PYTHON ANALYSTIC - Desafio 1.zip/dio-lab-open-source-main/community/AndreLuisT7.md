# André Luis 

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/public-profile/settings?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_self_edit_contact-info%3B5fcnbE5SSOWF645lb4rdNA%3D%3D)

## Habilidades 
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![C++](https://img.shields.io/badge/C%2B%2B-000?style=for-the-badge&logo=c%2B%2B&logoColor=00599C)
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)
![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

