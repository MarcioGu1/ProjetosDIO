Sua sugestão está relacionada a um problema? Por favor descreva.
Não.

Descreva a solução que você gostaria
Adicionar informações referentes a padronização das mensagens dos commits no Guia de Contribuição.

Descreva as alternativas que você considerou
Inserir uma tabela demonstrando os tipos de commits e uma descrição a respeito de seu uso.

Contexto adicional
N/A.
