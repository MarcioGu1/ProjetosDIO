### Ola! eu sou o Alessandro da Mata 👋
[![Linkdin](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/alessandro-da-mata-gon%C3%A7alves-4ba89311b) [![Portfolio](https://img.shields.io/badge/website-000000?style=for-the-badge&logo=About.me&logoColor=white)](https://portifolio-alessandro.onrender.com/)

<div>
    <img height="180em" src="https://github-readme-stats.vercel.app/api?username=Alessandro021&show_icons=true&theme=dracula&include_all_commits=true&count_private=true"/>
    <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Alessandro021&layout=compact&langs_count=10&theme=dracula" />
</div>

<!--
![Alessandro GitHub status](https://github-readme-stats.vercel.app/api?username=Alessandro021&show_icons=true&theme=radical)

[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=Alessandro021&Compact-layout=true)](https://github.com/Alessandro021/github-readme-stats)
-->

### Tecnologias que uso no meu dia a dia

<div style="display: inline_block"><hr/>
    <img align="center" alt="JavaScript" src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black" />
    <img align="center" alt="nodeJS" src="https://img.shields.io/badge/Node.js-43853D?style=for-the-badge&logo=node.js&logoColor=white" />
    <img align="center" alt="HTML5" src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white" />
    <img align="center" alt="CSS3" src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white" />
    <img align="center" alalt="react" src="https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB" />
    <img align="center" alt="react native" src="https://img.shields.io/badge/React_Native-20232A?style=for-the-badge&logo=react&logoColor=61DAFB" />
    <img align="center" alt="google cloud" src="https://img.shields.io/badge/Google_Cloud-4285F4?style=for-the-badge&logo=google-cloud&logoColor=white" />
    <img align="center" alt="visual studio" src="https://img.shields.io/badge/Visual_Studio-5C2D91?style=for-the-badge&logo=visual%20studio&logoColor=white" />
</div><br/>
<p style="text-align: justify;">
Como estudante de Bacharelado em Sistemas de Informação no Instituto Federal do Norte de Minas Gerais - Campus Arinos, estou constantemente inspirado pela             capacidade da tecnologia de transformar o mundo. Estou comprometido em aprimorar minhas habilidades de desenvolvimento de software e, eventualmente, criar             soluções criativas que possam fazer a diferença na vida das pessoas.
</p>



<!-- Com sede por conhecimento e inovação, estou sempre em busca de novas tecnologias para desenvolver aplicativos móveis incríveis, utilizando as habilidades adquiridas em meu curso de bacharelado em Sistemas de Informação no Instituto Federal do Norte de Minas Gerais - Campus Arinos, e me aprimorando em ferramentas como Expo e React Native. -->


<!-- https://emojipedia.org/ -->
<!-- https://dev.to/envoy_/150-badges-for-github-pnk -->

