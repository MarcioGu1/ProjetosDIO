
[![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=87CEFA&size=35&center=true&vCenter=true&width=1000&lines=Nice+to+meet+you,+my+name+is+Antônio;Welcome+to+my+GitHub+Profile!:%29)](https://git.io/typing-svg)

# 😁Who am i?


Olá, bem vindo ao meu perfil, meu nome é Antônio Paes, seu anfitrião. Aqui encontrará muita coisa boa ao longo do tempo. Ainda está em desenvolvimento, mas é essa a intenção, desenvolver. 
Tenho 22 anos e sempre tive fascínio pelo mundo da Tecnologia e Computação, desde a primeira vez que tive contato com um console ou um computador, seja jogando Super Mario Bros, vendo memes no Facebook ou hoje programando, sabia que aquilo era pra mim. Comecei a me interessar realmente pela programação este ano (2023), pois possuía somente conhecimentos superficiais sobre, desde então estudo para me tornar cada vez melhor. Em 2023 comecei a cursar Ciências Econômicas na UFPE e sabendo que o mundo da tecnologia é extremamente amplo e como Sou APAIXONADO por blockchain, criptos e programação, decidi cair com tudo nesse mundo da tecnologia! Meus primeiros passos foram os certificados da linux foundation e o início do curso CS50'P. Agora, após um tempo passei no Bootcamp do santander, conheci a plataforma DIO e irei me empenhar 100x mais para realizar meus sonhos! 
## Social Midia:

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/antôniopaess/) 

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/antonio_paes/)



## Contribuition:

[![Alan's github activity graph](https://github-readme-activity-graph.vercel.app/graph?username=AntonioPaess&bg_color=0d1117&color=6695b2&line=ffffff&point=ff0000&area=true&hide_border=true)](https://github.com/ashutosh00710/github-readme-activity-graph)




  

### Main skills:
![GitHub](https://img.shields.io/badge/-GitHub-0D1117?style=for-the-badge&logo=github&labelColor=0D1117)&nbsp;
![Git](https://img.shields.io/badge/-Git-0D1117?style=for-the-badge&logo=git&labelColor=0D1117)&nbsp;

## Status Github:

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AntonioPaess&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)



### Tools:
![Visual Studio Code](https://img.shields.io/badge/-Visual%20Studio%20Code-0D1117?style=for-the-badge&logo=visual-studio-code&logoColor=007ACC&labelColor=0D1117)&nbsp;
![Git](https://img.shields.io/badge/-Git-0D1117?style=for-the-badge&logo=git&labelColor=0D1117)&nbsp;
![GitHub](https://img.shields.io/badge/-GitHub-0D1117?style=for-the-badge&logo=github&labelColor=0D1117)&nbsp;
![Windows](https://img.shields.io/badge/-Windows-0D1117?style=for-the-badge&logo=windows&labelColor=0D1117)&nbsp;
![microsoft-office](https://img.shields.io/badge/-microsoft_office-0D1117?style=for-the-badge&logo=microsoft-office&labelColor=0D1117)&nbsp;

## My Streaks:

[![GitHub Streak](https://streak-stats.demolab.com/?user=AntonioPaess&theme=bear&background=000&border=30A3DC&dates=FFF)](https://git.io/streak-stats)

  
### Studying in this moment:
![Python](https://img.shields.io/badge/Python-14354C?style=for-the-badge&logo=python&logoColor=white)&nbsp; 
![SQL](https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white)&nbsp;

