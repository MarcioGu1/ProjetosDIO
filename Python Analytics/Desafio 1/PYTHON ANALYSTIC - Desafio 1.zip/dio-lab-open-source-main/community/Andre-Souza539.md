# André Souza

### Social 

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/andre-j-souza/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/andre.lj.souza/)

---

### Habilidades: 

HTML [![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)](html)

CSS [![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)](css)

JavaScript ![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript])



---

