Olá, meu nome é Afonso Tomaz de Aquino, tenho 20 anos de idade, e estou no 7 periodo da faculdade de sistemas de informação.
Sou apaixonado por tecnologia e cai de cabeça no mundo da programação, por agora dou pequenos passos concluindo este bootcamp de logica de programação
mas estou seguindo firme agora para o HTML e CSS e ao tão aguardado JavaScript, e poder ter conhecimento para me tornar um programador de qualidade tecnica boa :D
