# Antonio Sousa
Eu me chamo Antonio Sousa, e estou no mundo de TI estudando para melhorar minhas habilidades e me tronar um desenvolvedor.

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/antonio-sousa-741368225/)

## Habilidades
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![React](https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)

## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AntonioWSousa&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)