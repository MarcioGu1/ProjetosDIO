
# Ana Possani

Sou Dev desde 2002, com formação em Análise e Desenvolvimento de Sistemas pela UNIPAR. Ao longo dos anos, excerci diferentes papeis na área da técnologia atuando como Dev, Scrum Master e também como gestora de equipes.

Estou constantemente em busca de aprendizado, ansiosa por explorar novas tecnologias e tendências. Meu objetivo é aprimorar minhas habilidades e continuar enfrentando desafios empolgantes na área da tecnologia



## Tecnologias e Ferramentas
*Estou abandonado o péssimo hábito de versionar 0.01% dos meus projetos*
* Uniface
* Clipper
* Harbour / xHarbour
* Jira
* Git
* GitHub
* Gitflow
* JavaScript
* PHP
* Java - Iniciante
* C# - Iniciante
* GoLang - Iniciante
* Scrum 

![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=Anattion&theme=panda&hide_title=true)









## Redes Sociais
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/ana-possani/) 
[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/ana__possani/)