## Hello World...  <img src="https://github.com/Antonio-Marcos86/Antonio-Marcos86/blob/main/hey.gif?raw=true" width="32px"> 

[![Connect on LinkedIn](https://img.shields.io/badge/--linkedin?label=LinkedIn&logo=LinkedIn&style=social)](https://www.linkedin.com/in/ant%C3%B4nio-marcos-dos-santos-de-souza-0308781b6/)  [![Connect on LinkedIn](https://img.shields.io/static/v1?label=Salesforce&message=Trailhead&color=blue)](https://trailblazer.me/id/adossantosdesouza)  [![followersGit](https://img.shields.io/github/followers/Antonio-Marcos86?style=social)](https://github.com/Antonio-Marcos86) <img src="https://komarev.com/ghpvc/?username=Antonio-Marcos86&label=Profile%20views&color=0e75b6&style=social" alt="Antonio marcos dos Santos de Souza" /> ![Dev](https://img.shields.io/badge/Dev-Antonio%20Marcos-orange)

## Quem sou.

Olá, me chamo **Antonio Marcos dos Santos de Souza**, tenho 38 anos de idade. Estudante de **Análise e Desenvolvimento de Sistemas na <a href="https://www.uninter.com/?gclid=Cj0KCQiA9P__BRC0ARIsAEZ6irhdtKcrq5EybdPHNhfdTe8pFvbZ7MxL7R-5mE48vMMSrIUAP1n1xR4aAkQKEALw_wcB" target="_blank">Uninter</a>**, atualmente trabalho como  **programador Salesforce Pleno na <a href="https://www.accenture.com/br-pt" target="_blank">Accenture</a>**. Iniciando na área de desenvolvimento, com experiência na liderança de equipe. Conhecimento técnico com lógica de programação e diversas linguagens de programação, buscando continuamente me aperfeiçoar, sempre buscando conhecimento através do curso superior e também de cursos complementares de diversas linguagens de programação. 

## Conteúdo

  
- [Hello World...  <img src="https://github.com/Antonio-Marcos86/Antonio-Marcos86/blob/main/hey.gif?raw=true" width="32px">](#hello-world--)
- [Quem sou.](#quem-sou)
- [Conteúdo](#conteúdo)
- [O que estou fazendo atualmente?](#o-que-estou-fazendo-atualmente)
- [Objetivo](#objetivo)
- [Tecnologias, Ferramentas e Linguagens.](#tecnologias-ferramentas-e-linguagens)
- [Meu status no GitHub:](#meu-status-no-github)
- [Onde moro](#onde-moro)

## O que estou fazendo atualmente?
- 🏢 Trabalhando atualmente como programador Salesforce na **<a href="https://www.accenture.com/br-pt" target="_blank">Accenture</a>**
  
- 📓 Estudando para certificações Salesforce.

- 📚 Lendo muitos livros.

- 💰 Tenho atuado no mercado financeiro.

- 📚 Fazendo cursos complementares na área de tecnologia.

- 💻 Cursando Análise e desenvolvimento de sistemas.

- 💻 Cursando inglês.


## Objetivo

* 💻 Aprender a desenvolver; <br />
* 📰 Ter uma profissão dentro da área de TI;<br />
* 🔝 Sempre buscando aperfeiçoamento;

[Voltar ao topo](#quem-sou)
<br/>
________
## Tecnologias, Ferramentas e Linguagens.

<code><img width="20%" src="https://www.vectorlogo.zone/logos/visualstudio_code/visualstudio_code-ar21.svg"></code>
<code><img width="20%" src="https://www.vectorlogo.zone/logos/git-scm/git-scm-ar21.svg"></code>
<code><img width="20%" src="https://www.vectorlogo.zone/logos/github/github-ar21.svg"></code>
<code><img width="20%" src="https://www.vectorlogo.zone/logos/w3_html5/w3_html5-ar21.svg"></code>
<code><img width="20%" src="https://www.vectorlogo.zone/logos/salesforce/salesforce-ar21.svg"></code>
<code><img width="20%" src="https://www.vectorlogo.zone/logos/java/java-ar21.svg"></code>
<code><img width="20%" src="https://www.vectorlogo.zone/logos/android/android-ar21.svg"></code>
<code><img width="20%" src="https://www.vectorlogo.zone/logos/commonmark/commonmark-ar21.svg"></code>
<code><img width="20%" src="https://www.vectorlogo.zone/logos/mysql/mysql-ar21.svg"></code>
<code><img width="20%" src="https://www.vectorlogo.zone/logos/flutterio/flutterio-ar21.svg"></code>
<code><img width="20%" src="https://www.vectorlogo.zone/logos/reactjs/reactjs-ar21.svg"></code>

[Voltar ao topo](#quem-sou)

## Meu status no GitHub:

<img align="center" src="https://github-readme-stats.vercel.app/api?username=Antonio-Marcos86&theme=dracula&show_icons=true&locale=en" alt="Antonio-marcos86"/>

## Top Linguagens utilizadas
[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=Antonio-marcos86&layout=compact)](https://https://github.com/Antonio-Marcos86)

[Voltar ao topo](#quem-sou)
## Onde moro
Moro em **Curitiba**, capital do **Paraná**.

<img src="https://user-images.githubusercontent.com/71250901/104644013-00935d80-568c-11eb-8b60-9c8a94a2f25f.png" width="50%"> 
<img src="https://user-images.githubusercontent.com/71250901/104644290-56680580-568c-11eb-8ff0-e65837ae7320.png" width="50%">


[Voltar ao topo](#quem-sou)
