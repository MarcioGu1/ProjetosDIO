<div align="center">
  <img style="border-radius:100px;" height="150" src="https://avatars.githubusercontent.com/u/66881947?v=4"  />
</div>

###

<div align="center">
  <a href="https://www.linkedin.com/in/ademirsmonteiro/" target="_blank">
    <img src="https://img.shields.io/badge/-LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=white&color=0077B5" height="25" alt="linkedin logo"  />
  </a>
  <a href="mailto:ademirmsfilho@fac.pe.senac.br" target="_blank">
    <img src="https://img.shields.io/badge/Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=white&color=D74740" height="25" alt="discord logo"  />
  </a>
</div>

##

### 👾 Sobre mim

Me chamo Ademir Monteiro, sou graduado em Análise e Desenvolvimento de Sistemas, e atuo como Desenvolvedor Júnior. Venho me dedicando nos últimos anos ao desenvolvimento de soluções tecnológicas, utilizando Python e ferramentas de Low-Code e/ou No-Code.

Possuo habilidades sólidas em Python, Flask, Git, GitHub, PHP, Jinja, HTML, CSS e leitura de documentação técnica. Além disso, estou familiarizado com trabalho em equipe, metodologias ágeis, resolução de problemas, proatividade e raciocínio lógico.

-📚 Atualmente esotu estudando Java<br>
-⚡ Quando estou livre gosto de estar entre a família e amigos

##