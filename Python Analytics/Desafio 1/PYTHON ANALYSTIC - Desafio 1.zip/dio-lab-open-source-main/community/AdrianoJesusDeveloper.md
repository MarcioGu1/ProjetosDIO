# Sejam bem vindos 👋

<div> 
  <p>Sou Bacharel em Sistemas de Informação pela Universidade Estacio de Sá, estudante de Ciencias de Dados. Sou apaixonado por tecnologias inovadoras para o desenvolvimento de aplicações Web e Android e recentemente também me apaixonei pela ciência dos dados, ferarramentas de Business Inteligence e Machine Learning.  
  </p>
</div>
Conecte-se Comigo
  <div> 
    <a href="https://www.linkedin.com/in/adriano-costa-803b91104//" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a>
    <a href="https://discord.gg/AdrianoJC#7329" target="83Rfl#3843"><img src="https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white" target="_blank"></a>
    </div>

  
  
 Minhas Tecnologias 
<div>
  <img alig="center" alt="HTML5" height="50" width="47" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original-wordmark.svg"/>
  <img alig="center" alt="CSS" height="50" width="47" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original-wordmark.svg"/>
  <img alig="center" alt="JAVASCRIPT" height="42.5" width="35" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg"/>
  <img alig="center" alt="BOOTSTRAP" height="42.5" width="50" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-original-wordmark.svg"/>
  <img alig="center" alt="React" height="42" width="37" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original-wordmark.svg"/>  
  <img alig="center" alt="Python" height="40" width="47" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original-wordmark.svg"/>
  <img alig="center" alt="Firebase" height="45" width="47" src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/firebase/firebase-plain-wordmark.svg"/>         
</div>

<div  align="center">
  <a href="https://github.com/AdrianoJesusDesenvolvedor">
   <img height"170em" src"https//github-readme-stars.vercel.app/api?username=AdrianoJesusDesenvolvedor&show_icons=true&theme=dark&iclude-all_commits=true&count_private=true"/>
</div>