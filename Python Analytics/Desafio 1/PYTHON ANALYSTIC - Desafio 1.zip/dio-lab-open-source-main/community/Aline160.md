# Aline Pereira :octocat:

---

### Ei, tudo bem? 👋

> Meu nome é Aline, sou desenvolvedora Full Stack;

- 👩‍💼 Graduada em Sistemas de Informação 💙
- 👩‍💼 Graduada em Nutrição 💙

<div align="center">
  <img height="180em" src="https://github-readme-stats.vercel.app/api?username=Aline160&show_icons=true&theme=merko&include_all_commits=true&count_private=true"/>
  <img height="180em" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Aline160&layout=compact&langs_count=10&theme=merko"/>
</div>

[![Linkedin Badge](https://img.shields.io/badge/-LinkedIn-blue?style=flat-square&logo=Linkedin&logoColor=white&link=https:/https://www.linkedin.com/in/aline-pereira-70276161/)](https://www.linkedin.com/in/aline-pereira-70276161/)

![](http://estruyf-github.azurewebsites.net/api/VisitorHit?user=Aline160&repo=Aline160&countColorcountColor)
