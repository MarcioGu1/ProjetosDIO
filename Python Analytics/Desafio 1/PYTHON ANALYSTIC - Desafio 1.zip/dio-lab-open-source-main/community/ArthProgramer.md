# ARTHUR BATISTA ANANIAS

## SOBRE MIM

Olá! Sou estudante de Sistemas da Informação e estagiário de TI em Suporte/Infra. Meu objetivo é conseguir alguma experiência na área de desenvolvimento para conseguir aprofundar ainda mais nos meus estudos de forma prática. 

## HARD SKILLS

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)

## REDE SOCIAIS
	
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/arthur-batista-ananias-3b1149237/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/arthur_b_a/)

