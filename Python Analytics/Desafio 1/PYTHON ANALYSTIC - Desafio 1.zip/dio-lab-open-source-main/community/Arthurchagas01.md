# Arthur Chagas

## My social-media

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/arthur-chagas-72842a4a/)

[![Instagram](https://img.shields.io/badge/Instagram-000?style=for-the-badge&logo=instagram)](https://www.instagram.com/arthurgpchagas/)

## Habilities

![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python)

![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)


## GitHub Stats

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Arthurchagas01&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Arthurchagas01&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Arthurchagas01&repo=Chatbot-for-Reconciliation-Process-Project&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Arthurchagas01/Chatbot-for-Reconciliation-Process-Project)

## My Contribuitions

[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Arthurchagas01&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/Arthurchagas01/dio-lab-open-source)
