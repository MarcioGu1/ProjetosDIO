# AdonisTrindadeJr

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/adonis-trindade-jr/)

## Sobre
#### Adonis Sérgio Trindade Junior, atualmente cursando Analise e Desenvolvimento de Sistemas, pela Universidade Paulista - UNIP e com formação prevista para Julho de 2024 .

## Habilidades

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![Java](https://img.shields.io/badge/Java-000?style=for-the-badge&logo=java)
![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085)

#### 1Z0-1085-23 | Oracle Cloud Infrastructure
#### AWS Cloud Quest
#### Santander Bootcamp 2023 - Backend Java
#### Bootcamp DIO 2021 - Digital Innovation One - HTML WEB DEVELOPER
#### Java COMPLETO 2023 Programação Orientada a Objetos +Projetos - Prof. Nélio Alves

