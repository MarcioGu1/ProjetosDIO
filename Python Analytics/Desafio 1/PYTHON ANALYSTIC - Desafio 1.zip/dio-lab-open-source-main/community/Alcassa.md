### Olá, Seja bem vindo ao meu perfil
Meu nome é Guilherme Alcassa Nascimento tenho 16 anos, estudo programação desde os 14 anos onde comecei com ![Python](https://img.shields.io/badge/Python-000?style=for-the-badge&logo=python).

Atualmente faço curso tecnico de Desenvolvimento de Sistemas na ETEC Fernando Preste.
Hoje em dia a minha liguaguem de programação dominante é ![C#](https://img.shields.io/badge/C%23-000?style=for-the-badge&logo=c-sharp&logoColor=823085) , porem agora pretendo aprender java e entre outras.

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Alcassa&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

##Links para contato
	
 
 [![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/guilherme-alcassa-nascimento-59b476281/)




