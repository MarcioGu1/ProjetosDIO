# Perfil

Bem-vindo ao meu perfil! Eu sou Ana Luisa, sou desenvolvedora front-end, estou no último semestre do curso Análise e desenvolvimento de sistemas. Sou apaixonada por jogos e esportes. Atualmente, estou focada em conseguir minha primeira vaga como dev.júnior.

## Sobre Mim

- 🔭 Atualmente trabalhando em um projeto no estágio com as linguagens: C#/.NET e Angular
- 🌱 Estou aprendendo Angular, React, Typescript
- 📫 Como me encontrar: https://www.linkedin.com/in/ana-luisa-bonjardim-barros-30b5181b6/

## Educação

- [Superior] - [Ceub]

## Experiência Profissional

- [Estágio] - [Caixa Econômica Federal]

## Contato

- [Email] (anabonjardimbarros@gmail.com)
