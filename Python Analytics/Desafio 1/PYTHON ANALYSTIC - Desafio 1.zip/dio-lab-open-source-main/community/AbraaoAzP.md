 Abraão Azevedo Pereira

## 🚀 Sobre mim

Olá! Estou em processo de transição de carreira para a área de tecnologia. Atualmente estou fazendo um curso de algoritmos e os conteúdos do bootcamp da DIO.

## Conecte-se comigo
[![Instagram](https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/abraaoazp/)
[![Discord](https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white)](https://https://discord.com/channels/abraao.a.pereira/)
[![E-mail](https://img.shields.io/badge/-Email-000?style=for-the-badge&logo=microsoft-outlook&logoColor=007BFF)](mailto:abraaoazp@gmail.com)
[![WhatsApp](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/+55011988672953)
## Estou Aprendendo
![Markdown](https://img.shields.io/badge/Markdown-000?style=for-the-badge&logo=markdown)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)
## GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=AbraaoAzP&theme=transparent&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
## Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=AbraaoAzP&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)](https://github.com/AbraaoAzP/dio-lab-open-source)