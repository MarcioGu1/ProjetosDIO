## Rafael Naoki Arakaki Uyeta

Bem-vindos ao meu GitHub! Aqui, você acompanhará minha jornada de aprendizado. Atualmente, estou cursando Bacharelado em Ciência da Computação na UFSCar. Estou realizando esse desafio devido a um bootcamp em Kotlin que estou realizando na DIO.

### Onde me encontrar
[![Github](https://img.shields.io/badge/Github-000?style=for-the-badge&logo=github)](https://github.com/Arata2703)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/rafael_uyeta/)