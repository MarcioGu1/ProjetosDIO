# *Vanessa Aquino* 

Olá! Sou a Vanessa, iniciante na área de programação, e sempre gostei da área, mas somente agora decidi migrar de profissão para finalmente aprender e exercer a carreira que eu sempre quis. Está sendo um desafio, mas acredito que conseguirei superar minhas próprias expectativas. 

## Conecte-se comigo
[![LinkedIn](https://img.shields.io/badge/LinkedIn-D19275?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/vanessa-vieira-de-aquino-2343a3a8)

[![Discord](https://img.shields.io/badge/Discord-FFFF00?style=for-the-badge&logo=discord)](https://www.discord.com/in/nessa0682/)

[![GitHub](https://img.shields.io/badge/GitHub-ccffff?style=for-the-badge&logo=github&logoColor=000000)](https://www.github.com/Angelnessa/)

### Habilidades
[![GitHub](https://img.shields.io/badge/GitHub-ccffff?style=for-the-badge&logo=github&logoColor=000000)](https://docs.github.com)
[![Git](https://img.shields.io/badge/Git-ccffff?style=for-the-badge&logo=git&logoColor=ff6600)](https://git-scm.com/doc/)

### GitHub Stats
![GitHub Stats](https://github-readme-stats.vercel.app/api?username=Angelnessa&theme=transparent&bg_color=238e68&border_color=8e236b&show_icons=true&icon_color=ffcc00&title_color=993366&text_color=ff9900&hide_title=true)

### Minhas Contribuições
[![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Angelnessa&repo=dio-lab-open-source&bg_color=871f78&border_color=db7093&show_icons=true&icon_color=adeaea&title_color=dbdb70&text_color=ff7f00)](https://github.com/Angelnessa/dio-lab-open-source)

![Imagem](https://www.imagensanimadas.com/data/media/942/anime-imagem-animada-0087.gif)