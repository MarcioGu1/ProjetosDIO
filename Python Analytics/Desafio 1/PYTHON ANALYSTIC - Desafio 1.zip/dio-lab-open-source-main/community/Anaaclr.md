# Ana Clara Pereira

### Conecte-se comigo

[![LinkedIn](https://img.shields.io/badge/LinkedIn-000?style=for-the-badge&logo=linkedin&logoColor=0E76A8)](https://www.linkedin.com/in/ana-clara-silva-b05b851bb/)
[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://www.discord.com/in/anaaaaa1312/)
[![Perfil DIO](https://img.shields.io/badge/DIO-000?style=for-the-badge&logo=)](https://web.dio.me/users/annaclara02silva?tab=skills)

# Sobre Mim

### Me chamo Ana Clara tenho 21 anos e sou estudante do curso de Gestão da tecnologia e informação, atualmente trabalho na área financeira, mas busco uma migração no mercado de trabalho para área de tecnologia.Atualmente além da faculdade estudo por fora realizando cursos de programação pela DIO, ADA e Udemy, assim, pensando no futuro adquirir conhecimentos necessários para me tornar uma desenvolvedora FullStack.Estou aberta a oportunidades de trabalho na área.

## Habilidades

![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)
![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)
![MySQL](https://img.shields.io/badge/mysql-000?style=for-the-badge&logo=mysql&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)
![Angular](https://img.shields.io/badge/Angular-000?style=for-the-badge&logo=angular&logoColor=C3002F)
![React](https://img.shields.io/badge/React-000?style=for-the-badge&logo=react)
![Git](https://img.shields.io/badge/git-000?style=for-the-badge&logo=git&logoColor=C3002F)

## Soft Skills

![Organizada](https://img.shields.io/badge/Organizada-black)
![Produtiva](https://img.shields.io/badge/Produtiva-darkblue)
![Comunicativa](https://img.shields.io/badge/Comunicativa-black)
![Proativa](https://img.shields.io/badge/Proativa-darkblue)

## GitHub Status

![Top Langs](https://github-readme-stats-git-masterrstaa-rickstaa.vercel.app/api/top-langs/?username=Anaaclra&layout=compact&bg_color=000&border_color=30A3DC&title_color=E94D5F&text_color=FFF)

## Minhas Contribuições

![Repo Card](https://github-readme-stats.vercel.app/api/pin/?username=Anaaclra&repo=dio-lab-open-source&bg_color=000&border_color=30A3DC&show_icons=true&icon_color=30A3DC&title_color=E94D5F&text_color=FFF)
