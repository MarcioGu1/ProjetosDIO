### Olá 👋
- Sou um desenvolvedor tipo espagueti, talvez miojo, mas resolve a fome na hora que precisa;
- Sou péssimo em UI/UX;
- Tirei até nota boa na disciplina de programação, mexendo com C, lá no IC/Unicamp, mas fiz mesmo Física/IFGW;
- Gosto de brincar com sistemas embarcados;
- Gosto de Software Livre, tecnologias abertas, desmontar e modificar quase qualquer coisa;
- Gosto de Códigos e de receitas.
  
