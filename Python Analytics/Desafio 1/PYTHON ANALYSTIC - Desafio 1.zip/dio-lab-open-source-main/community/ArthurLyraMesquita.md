# Arthur Lyra Mesquita

## Sobre:
Olá, tudo bem? Meu nome é Arthur e sou estudante universitário e amo programar. Estudo programação para Web a um tempo e quero trabalhar com Front-End e depois evoluir pra Full-Stack. Atualmente estou fazendo o BootCamp da Dio de Full-Stack Java.

## Habilidades:
![HTML5](https://img.shields.io/badge/HTML5-000?style=for-the-badge&logo=html5)

![CSS3](https://img.shields.io/badge/CSS3-000?style=for-the-badge&logo=css3&logoColor=264CE4)

![JavaScript](https://img.shields.io/badge/JavaScript-000?style=for-the-badge&logo=javascript)

![C](https://img.shields.io/badge/C-000?style=for-the-badge&logo=c)

## Redes Sociais
[![Discord](https://img.shields.io/badge/Discord-000?style=for-the-badge&logo=discord)](https://discord.com/channels/@Idoninho)
