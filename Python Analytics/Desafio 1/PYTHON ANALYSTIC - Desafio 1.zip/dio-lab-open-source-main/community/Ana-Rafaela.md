# Ana Rafaela

## 💫 About Me:
🤝 Tenho curso técnico de multimídia<br>🌱 Sou iniciante na área de TI<br>🔭 Busco conhecimento no ramo <br><br>

## 🌐 Socials:

[![LinkedIn](https://img.shields.io/badge/LinkedIn-%230077B5.svg?logo=linkedin&logoColor=white)](https://linkedin.com/in/ana-rafaela-alves-908495209) 

## 🚀Skills:

![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white)

# 📊 GitHub Stats:
![](https://github-readme-stats.vercel.app/api?username=Ana-Rafaela&theme=radical&hide_border=false&include_all_commits=false&count_private=false)<br/>
![](https://github-readme-streak-stats.herokuapp.com/?user=Ana-Rafaela&theme=radical&hide_border=false)<br/>
![](https://github-readme-stats.vercel.app/api/top-langs/?username=Ana-Rafaela&theme=radical&hide_border=false&include_all_commits=false&count_private=false&layout=compact)

---