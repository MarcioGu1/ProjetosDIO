
# **Bem Vindo ao meu Perfil**

## Quem sou eu?

- | Gosto de **Ciência** e **Tecnologia** 🤖
- | Estudo na **UFABC** 🎓
- | Gosto de **Java** 👨‍💻

## Sei utilizar:
- | HTML CSS 
- | JavaScript PHP
- | MYSQL
- | JAVA
- | NODE

## Para me conhecer melhor:

[![Github](https://img.shields.io/badge/Github-357?style=for-the-badge&logo=Github&logoColor=fffff)](https://github.com/ArthFreitas) 


[![LinkedIn](https://img.shields.io/badge/LinkedIn-357?style=for-the-badge&logo=linkedin&logoColor=ffff)](https://www.linkedin.com/in/arthur-vieira-freitas-de-jesus-89a955264/)




