### Olá, seja muito bem-vindo(a)! Eu sou o Ronald Aragão 👋
#### Cursando desenvolvimento de sistemas no [Senai](https://www.senaibahia.com.br/unidade/senaidendezeiros/)
[![Social](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/ronald-aragão2023)

![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=aragaoronald&show_icons=true)

## Tecnologias já utilizadas

<div style="display: inline_block"><br/>
    <img align="center" alt="html5" src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white" />
    <img align="center" alt="css3" src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white" />
    <img align="center" alt="javascript" src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black" />
    <img align="center" alt="bootstrap" src="https://img.shields.io/badge/Bootstrap-563D7C?style=for-the-badge&logo=bootstrap&logoColor=white" />
    <img align="center" alt="php" src="https://img.shields.io/badge/PHP-777BB4?style=for-the-badge&logo=php&logoColor=white" />
</div></br>


Com um profundo amor por transformar código em soluções práticas e inovadoras, estou pronto para mergulhar de cabeça em desafios e aprender com colegas inspiradores.

## Entre em contato:
- dev.ronaldaragao@gmail.com
